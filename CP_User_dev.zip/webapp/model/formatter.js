sap.ui.define([], function () {
    "use strict";

    return {
        /**
         * Rounds the currency value to 2 digits
         *
         * @public
         * @param {string} sValue value to be formatted
         * @returns {string} formatted currency value with 2 digits
         */
        currencyValue : function (sValue) {
            if (!sValue) {
                return "";
            }

            return parseFloat(sValue).toFixed(2);
        },
        	checked: function(fValue) {
			if (fValue === "X") {
				return true;
			} else {
				return false;
			}
		},
			isActive: function(fValue) {
			if (fValue === "X") {
				return "Success";
			} else {
				return "Warning";
			}
		},
		isActiveText: function(fValue) {
			if (fValue == "") {
				return "Active";
			} else {
				return "In Active";
			}
		},
		isInfoActiveText: function(fValue) {
			if (fValue == "") {
				return "In Active";

			} else {
				return "Active";
			}
		},
		isActiveTextStatus: function(fValue) {
			if (fValue == "") {
				return "Success";
			} else {
				return "Warning";
			}
		},
			onGenerateAttachURL:function(fileID,FileName){
			return "/sap/opu/odata/sap/ZCONTACTOR_PORTAL_SRV/INFOCONTENTSet(FileId='"+fileID+"',FileName='"+FileName+"')/$value";
		}
    };
});