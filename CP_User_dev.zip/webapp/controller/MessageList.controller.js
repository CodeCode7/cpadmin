sap.ui.define([
	"./BaseController",
	'sap/m/library',
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/Sorter",
	"sap/ui/model/FilterOperator",
	"sap/m/GroupHeaderListItem",
	"sap/ui/Device",
	"sap/ui/core/Fragment",
	"../model/formatter",
	'sap/m/MessageBox',
	'sap/ui/table/TablePersoController',
	'../model/tableFunc',
	'sap/m/Menu',
	'sap/m/MenuItem'
], function(BaseController, mlibrary, JSONModel, Filter, Sorter, FilterOperator, GroupHeaderListItem, Device, Fragment, formatter, MessageBox, 
TablePersoController, tableFunc) {
	"use strict";
	var ResetAllMode =  mlibrary.ResetAllMode;
	var Variants;
	return BaseController.extend("com.avangrid.ui.cpuser.controller.MessageList", {

		formatter: formatter,
		onInit: function() {
			this.oView = this.getView();
			this._bDescendingSort = false;
			this.oMessageTable = this.oView.byId("messageTable");
			this.oRouter = this.getOwnerComponent().getRouter();
			
				var oViewModel,
					iOriginalBusyDelay,
					oTable = this.byId("messageTable");

				// Put down worklist table's original value for busy indicator delay,
				// so it can be restored later on. Busy handling on the table is
				// taken care of by the table itself.
				iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
				// keeps the search state
				this._aTableSearchState = [];

				// Model used to manipulate control states
				oViewModel = new JSONModel({
					worklistTableTitle : this.getResourceBundle().getText("worklistTableTitle"),
					shareOnJamTitle: this.getResourceBundle().getText("worklistTitle"),
					shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
					shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
					tableNoDataText : this.getResourceBundle().getText("tableNoDataText"),
					tableBusyDelay : 0
				});
				this.setModel(oViewModel, "worklistView");

				// Make sure, busy indication is showing immediately so there is no
				// break after the busy indication for loading the view's meta data is
				// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
				oTable.attachEventOnce("updateFinished", function(){
					// Restore original busy indicator delay for worklist's table
					oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
				});
			 //   this._oTPC = new TablePersoController({
				// table: this.byId("messageTable"),
				// componentName: "com.avangrid.ui.cpadmin",
				 //resetAllMode: ResetAllMode.ServiceReset,  //cmnt E834441
			// 	persoService: tableFunc
			// }).activate();
			// this._mViewSettingsDialogs = {};
			if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {

				var oComponent = sap.ui.core.Component.getOwnerComponentFor(this.getView());
				this.oPersonalizationService = sap.ushell.Container.getService("Personalization");
				var oPersId = {
					container: "TablePersonalisation", //any
					item: "messageTable" //any- I have used the table name
				};
				// define scope 
				var oScope = {
					keyCategory: this.oPersonalizationService.constants.keyCategory.FIXED_KEY,
					writeFrequency: this.oPersonalizationService.constants.writeFrequency.LOW,
					clientStorageAllowed: true
				};
				var oPersonalizer = this.oPersonalizationService.getPersonalizer(oPersId, oScope, oComponent);
				this.oPersonalizationService.getContainer("TablePersonalisation", oScope, oComponent)
					.fail(function() {})
					.done(function(oContainer) {
						this.oContainer = oContainer;
						this.oVariantSetAdapter = new sap.ushell.services.Personalization.VariantSetAdapter(this.oContainer);
						// get variant set which is stored in backend
						this.oVariantSet = this.oVariantSetAdapter.getVariantSet("messageTable");
						if (!this.oVariantSet) { //if not in backend, then create one
							this.oVariantSet = this.oVariantSetAdapter.addVariantSet("messageTable");
						}
						// array to store the existing variants
						Variants = [];
						// now get the existing variants from the backend to show as list
						for (var key in this.oVariantSet.getVariantNamesAndKeys()) {
							if (this.oVariantSet.getVariantNamesAndKeys().hasOwnProperty(key)) {
								var oVariantItemObject = {};
								oVariantItemObject.Key = this.oVariantSet.getVariantNamesAndKeys()[key];
								oVariantItemObject.Name = key;
								Variants.push(oVariantItemObject);
							}
						}
						// create JSON model and attach to the variant management UI control
						this.oVariantModel = new sap.ui.model.json.JSONModel();
						this.oVariantModel.oData.Variants = Variants;
						this.getView().byId("Variants").setModel(this.oVariantModel,"VariantsModel");
					}.bind(this));
						// create table persco controller
				this.oTablepersoService = new TablePersoController({
					table: this.getView().byId("messageTable"),
					persoService: oPersonalizer
				});

						}
		},

		onSearch: function(oEvent) {
			var oTableSearchState = [],
				sQuery = oEvent.getParameter("query");

			if (sQuery && sQuery.length > 0) {
				oTableSearchState = [new Filter("MessName", FilterOperator.Contains, sQuery)];
			}

			this.oMessageTable.getBinding("rows").filter(oTableSearchState, "Application");
		},

		// onAdd: function() {
		// 	MessageBox.information("This functionality is not ready yet.", {
		// 		title: "Aw, Snap!"
		// 	});
		// },
		//Arrange/ Rearrange Table columns
		// onhide: function (oEvent) {
		// 	this._oTPC.openDialog();
		// },
		
		// onSort: function() {
		// 	this._bDescendingSort = !this._bDescendingSort;
		// 	var oBinding = this.oMessageTable.getBinding("items"),
		// 		oSorter = new Sorter("MessId", this._bDescendingSort);

		// 	oBinding.sort(oSorter);
		// },  //cmnt by E859219
		
		// Sort individual columns dialogbox opens
		onSort: function() {
			var oView = this.getView();
			if(!this.byId("sortDialog")) {
				Fragment.load({
					id: oView.getId(),
					name: "com.avangrid.ui.cpuser.fragments.SortDialog",
					controller: this
				}).then(function (oDialog) {
					oView.addDependent(oDialog);
					oDialog.open();
				});
			} else {
				this.byId("sortDialog").open();
			}
		},
		//// Sort individual columns
		handleSortDialogConfirm: function (oEvent) {
			var oTable = this.byId("messageTable"),
				mParams = oEvent.getParameters(),
				oBinding = oTable.getBinding("rows"),
				sPath,
				bDescending,
				aSorters = [];

			sPath = mParams.sortItem.getKey();
			bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending));
			// apply the selected sort and group settings
			oBinding.sort(aSorters);
		}, //cmnt E859219

		onListItemPress: function(oEvent) {

			var	MessObj  =oEvent.getSource().getBindingContext().getProperty("MessId");
			//	var	MessObj = oEvent.getSource().getBindingContext().getPath();
			// oNextUIState;
			var bReplace = !Device.system.phone;
			// set the layout property of FCL control to show two columns
			this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
			this.getRouter().navTo("Meaasgeobject", {
				objectId: MessObj
			}, bReplace);

			// this.getOwnerComponent().getHelper().then(function(oHelper) {
			// 	oNextUIState = oHelper.getNextUIState(1);
			// 	this.oRouter.navTo("detail", {
			// 		layout: oNextUIState.layout,
			// 		product: product
			// 	});
			// }.bind(this));
		},
		
		onFilter: function() {
			var oView = this.getView();
			if (!this.byId("filterDialog")) {
				Fragment.load({
					id: oView.getId(),
					name: "com.avangrid.ui.cpuser.fragments.MessageFiterDialog",
					controller: this
				}).then(function(oDialog) {
					oView.addDependent(oDialog);
					oDialog.open();
				});
			} else {
				this.byId("filterDialog").open();
			}
		},
		handleFilterDialogConfirm: function(oEvent) {
			var oTable = this.byId("messageTable"),
				mParams = oEvent.getParameters(),
				oBinding = oTable.getBinding("rows"),
				aFilters = [];

			mParams.filterItems.forEach(function(oItem) {
				
				aFilters.push(new Filter(oItem.getKey(), FilterOperator.EQ, oItem.getText()));
			});

			// apply filter settings
			oBinding.filter(aFilters);

		},
		onExport:function(){
			var sUrl = "/sap/opu/odata/sap/ZCONTACTOR_PORTAL_SRV/MessageSet?$format=xlsx";
			var encodeUrl = encodeURI(sUrl);
			sap.m.URLHelper.redirect(encodeUrl, false);
		},
		onPersoButtonPressed: function(oEvent) {
			this.oTablepersoService.openDialog({
				ok: "this.onPerscoDonePressed.bind(this)"
			});
			this._waitForDialog(this);
		},
		_waitForDialog: function(that) {
			if (typeof that.oTablepersoService._oDialog !== "undefined") {
				that.oTablepersoService._oDialog.attachConfirm(that, that.onPerscoDonePressed.bind(that));
			} else {
				setTimeout(this._waitForDialog, 250, that);
			}
		},
		onPerscoDonePressed: function(oEvent) {
			this.oTablepersoService.savePersonalizations();
		},
		
		onSaveAs: function(oEvent) {
			// get variant parameters:
			var VariantParam = oEvent.getParameters();
			// get columns data: 
			var aColumnsData = [];
			this.getView().byId("messageTable").getColumns().forEach(function(oColumn, index) {
				var aColumn = {};
				aColumn.fieldName = oColumn.getProperty("name");
				aColumn.Id = oColumn.getId();
				aColumn.index = index;
				aColumn.Visible = oColumn.getVisible();
				aColumnsData.push(aColumn);
			});

			this.oVariant = this.oVariantSet.addVariant(VariantParam.name);
			if (this.oVariant) {
				this.oVariant.setItemValue("ColumnsVal", JSON.stringify(aColumnsData));
				if (VariantParam.def === true) {
					this.oVariantSet.setCurrentVariantKey(this.oVariant.getVariantKey());
				}
				this.oContainer.save().done(function() {
					// Tell the user that the personalization data was saved
				});
			}
		},
		onSelect: function(oEvent) {
			var selectedKey = oEvent.getParameters().key;
			for (var i = 0; i < oEvent.getSource().getVariantItems().length; i++) {
				if (oEvent.getSource().getVariantItems()[i].getProperty("key") === selectedKey) {
					var selectedVariant = oEvent.getSource().getVariantItems()[i].getProperty("text");
					break;
				}
			}
			this._setSelectedVariantToTable(selectedVariant);
		},

		_setSelectedVariantToTable: function(oSelectedVariant) {
			if (oSelectedVariant) {
				var sVariant = this.oVariantSet.getVariant(this.oVariantSet.getVariantKeyByName(oSelectedVariant));
				var aColumns = JSON.parse(sVariant.getItemValue("ColumnsVal"));

				// Hide all columns first
				this.getView().byId("messageTable").getColumns().forEach(function(oColumn) {
					oColumn.setVisible(false);
				});
				// re-arrange columns according to the saved variant

				aColumns.forEach(function(aColumn) {
					var aTableColumn = $.grep(this.getView().byId("messageTable").getColumns(), function(el, id) {
						return el.getProperty("name") === aColumn.fieldName;
					});
					if (aTableColumn.length > 0) {
						aTableColumn[0].setVisible(aColumn.Visible);
						this.getView().byId("messageTable").removeColumn(aTableColumn[0]);
						this.getView().byId("messageTable").insertColumn(aTableColumn[0], aColumn.index);
					}
				}.bind(this));
			}
			// null means the standard variant is selected or the variant which is not available, then show all columns
			else {
				this.getView().byId("messageTable").getColumns().forEach(function(oColumn) {
					oColumn.setVisible(true);
				});
			}
		},
		onManage: function(oEvent) {
			var aParameters = oEvent.getParameters();
			// rename variants
			if (aParameters.renamed.length > 0) {
				aParameters.renamed.forEach(function(aRenamed) {
					var sVariant = this.oVariantSet.getVariant(aRenamed.key),
						sItemValue = sVariant.getItemValue("ColumnsVal");
					// delete the variant 
					this.oVariantSet.delVariant(aRenamed.key);
					// after delete, add a new variant
					var oNewVariant = this.oVariantSet.addVariant(aRenamed.name);
					oNewVariant.setItemValue("ColumnsVal", sItemValue);
				}.bind(this));
			}
			// default variant change
			if (aParameters.def !== "*standard*") {
				this.oVariantSet.setCurrentVariantKey(aParameters.def);
			} else {
				this.oVariantSet.setCurrentVariantKey(null);
			}
			// Delete variants
			if (aParameters.deleted.length > 0) {
				aParameters.deleted.forEach(function(aDelete) {
					this.oVariantSet.delVariant(aDelete);
				}.bind(this));
			}
			//  Save the Variant Container
			this.oContainer.save().done(function() {
				// Tell the user that the personalization data was saved
			});
		},
		
        /* =========================================================== */
        /* event handlers                                              */
        /* =========================================================== */

      	/**
			 * Triggered by the table's 'updateFinished' event: after new table
			 * data is available, this handler method updates the table counter.
			 * This should only happen if the update was successful, which is
			 * why this handler is attached to 'updateFinished' and not to the
			 * table's list binding's 'dataReceived' method.
			 * @param {sap.ui.base.Event} oEvent the update finished event
			 * @public
			 */
			onUpdateFinished : function (oEvent) {
				// update the worklist's object counter after the table update
				var sTitle,
					oTable = oEvent.getSource(),
					iTotalItems = oEvent.getParameter("total");
				// only update the counter if the length is final and
				// the table is not empty
				if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
					sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
				} else {
					sTitle = this.getResourceBundle().getText("worklistTableTitle");
				}
				this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
			}
	

	});

});