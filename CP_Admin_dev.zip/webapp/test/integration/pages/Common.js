sap.ui.define([
	"sap/ui/test/Opa5"
], function(Opa5) {
	"use strict";

	return Opa5.extend("com.avangrid.ui.cpadmin.test.integration.pages.Common", {

	});

});