sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"../model/formatter",
	"sap/ui/model/json/JSONModel",
	"./BaseController",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Filter",
	"sap/m/MessageBox",
	"sap/ui/core/Fragment"

], function(Controller, formatter, JSONModel, BaseController, FilterOperator, Filter, MessageBox, Fragment) {
	"use strict";

	return BaseController.extend("com.avangrid.ui.cpadmin.controller.UserDetail", {
		formatter: formatter,
		onInit: function() {

			this.getRouter().getRoute("UserDetail").attachPatternMatched(this._onObjectMatched, this);

		},
		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			var ConUname = oEvent.getParameter("arguments").ConUname;
			this.getModel("appView").setProperty("/layout", "OneColumn");
			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("USERLISTSet", {
					ConUname: ConUname
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));
		},
		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		_bindView: function(sObjectPath) {

			this.getView().bindElement({
				path: sObjectPath
			});
		},
		onDeleteUserGroup: function(oEvent) {
			var aContexts = oEvent.getSource().getParent().getParent().getSelectedContextPaths();
			var oTable = this.getView().byId('idUserTable');
			//var selectedIndex = oTable.getSelectedIndex();
			if (aContexts) {
				this._onDeletedUsers = [];
				var that = this;
				var deleteUser = aContexts.map(function(oContext) {
					that._onDeletedUsers.push({
						"ConUname": that.getView().byId("iduserConUname").getValue(),
						"UserDel": "X"
					});

				});
				var tableData = oTable.getSelectedItem().getBindingContext().getObject();

				var Payload = {
					"GroupId": tableData.GroupId,
					"GroupName": tableData.GroupName,
					"GroupDescr": tableData.GroupDescr,
					"Inactive": tableData.Inactive,
					"UsergroupHeadToAssiNav": that._onDeletedUsers
				};
				this.getModel().create('/USERGROUPHEADSet', Payload, {
					success: function(oData, response) {
						if (response.headers["sap-message"]) {
							var hdrMessage = response.headers["sap-message"];
							var hdrMessageObject = JSON.parse(hdrMessage);
							MessageBox.error(hdrMessageObject.message);
						} else {
							MessageBox.success("User deleted in the group  Successfully");
							that.onRefresh();
							//that.getRouter().navTo("UserList");
						}

					},
					error: function() {
						// Error
						MessageBox.error("User deletion failed");
					}
				});
			}

		},

		onAddUserToGroup: function() {
			var oView = this.getView();
			if (!this.byId("AddGroupDialog")) {
				Fragment.load({
					id: oView.getId(),
					name: "com.avangrid.ui.cpadmin.fragments.AddGroupDialog",
					controller: this
				}).then(function(oDialog) {
					oView.addDependent(oDialog);
					oDialog.open();
				});
			} else {
				this.byId("AddGroupDialog").open();
			}
		},

		AddGroupToUsers: function(oEvent) {
			this._onMultipleUser = [];
			var that = this;
			var aContexts = oEvent.getParameter("selectedContexts");
			if (aContexts) {

				var Payload = {
					"GroupId": aContexts[0].getObject().GroupId,
					"GroupName": aContexts[0].getObject().GroupName,
					"GroupDescr": aContexts[0].getObject().GroupDescr,
					"Inactive": "",
					"UsergroupHeadToAssiNav": [{
						"ConUname": that.getView().byId("iduserConUname").getValue()
					}]
				};

				this.getModel().create('/USERGROUPHEADSet', Payload, {
					success: function(oData, response) {
						if (response.headers["sap-message"]) {
							var hdrMessage = response.headers["sap-message"];
							var hdrMessageObject = JSON.parse(hdrMessage);
							MessageBox.error(hdrMessageObject.message);
						} else {
							MessageBox.success("User added to group  Successfully");
							that.onRefresh();
							//that.getRouter().navTo("UserList");
						}

					},
					error: function() {
						// Error
						MessageBox.error("User adding  failed");
					}
				});
			}

		},

		onEditUserInfo: function() {
			this.getView().byId("idsaveUserInfo").setVisible(true);
			this.getView().byId("idEditAction").setVisible(false);
			this.getView().byId("idAddButton").setVisible(true);
			this.getView().byId("idDelButton").setVisible(true);
			this.getView().byId("idSuperUser").setEnabled(true);
		},

		onUserInfoSave: function(oEvent) {
			this.getView().byId("idEditAction").setVisible(true);
			this.getView().byId("idsaveUserInfo").setVisible(false);
			this.getView().byId("idAddButton").setVisible(false);
			this.getView().byId("idDelButton").setVisible(false);
			this.getView().byId("idSuperUser").setEnabled(false);
			var that = this;
			var Payload = {
				"ConUname": this.getView().byId("iduserConUname").getValue(),
				"Vendor": this.getView().byId("idVendorEdit").getValue(),
				"Superuser": (this.getView().byId("idSuperUser").getState() == true ? "X" : "")

			};

			this.getModel().create('/USERLISTSet', Payload, {
					success: function(oData, response) {
						if (response.headers["sap-message"]) {
							var hdrMessage = response.headers["sap-message"];
							var hdrMessageObject = JSON.parse(hdrMessage);
							MessageBox.error(hdrMessageObject.message);
							that.getView().byId("idSuperUser").setEnabled(false);
						} else {
							MessageBox.success("User details updated successfully");
							that.onRefresh();
							//that.getRouter().navTo("UserList");
						}

					},
					error: function() {
						// Error
						MessageBox.error("User details updated failed");
					}
				}

			);
		},
		onNavBack: function() {

			// if (sPreviousHash !== undefined) {
			// 	history.go(-1);
			// } else {

			this.getOwnerComponent().getRouter().navTo("UserList", {}, true);
			//}
		},
		onRefresh: function() {
			this.getView().getModel().read("/USERLISTSet", {
				urlParameters: {
					'$expand': "USERLISTTOGROUP"
				},

				success: function(oData) {

				},
				error: function(snItemsError1) {
					MessageBox.error(JSON.parse(snItemsError1.responseText).error.message.value);
				}
			});
			//this.getView().byId("idUserTable").getBinding("items").refresh();
		}

	});
});