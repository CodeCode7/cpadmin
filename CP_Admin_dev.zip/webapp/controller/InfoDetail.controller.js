sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"sap/m/library",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Filter",
	"sap/m/MessageBox"
], function(BaseController, JSONModel, formatter, mobileLibrary, FilterOperator, Filter, MessageBox) {
	"use strict";

	// shortcut for sap.m.URLHelper
	var URLHelper = mobileLibrary.URLHelper;

	return BaseController.extend("com.avangrid.ui.cpadmin.controller.InfoDetail", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0
			});

			this.getRouter().getRoute("Infoobject").attachPatternMatched(this._onObjectMatched, this);

			this.setModel(oViewModel, "detailView");
			this._oODataModel = this.getOwnerComponent().getModel();

			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));

		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler when the share by E-Mail button has been clicked
		 * @public
		 */
		onSendEmailPress: function() {
			var oViewModel = this.getModel("detailView");

			URLHelper.triggerEmail(
				null,
				oViewModel.getProperty("/shareSendEmailSubject"),
				oViewModel.getProperty("/shareSendEmailMessage")
			);
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			var sObjectId = oEvent.getParameter("arguments").objectId;
			this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
			if (sObjectId != "X") {
				this.getModel().metadataLoaded().then(function() {
					var sObjectPath = this.getModel().createKey("INFOPAGESet", {
						PageId: sObjectId
					});
					this._bindView("/" + sObjectPath);
				}.bind(this));
				this.onDisplayInfoPage();
			} else {
				this.onCreateNewInfoPage();
			}

		},

		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		_bindView: function(sObjectPath) {
			// Set busy indicator during view binding
			var oViewModel = this.getModel("detailView");

			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearListListSelection();
				return;
			}

			var sPath = oElementBinding.getPath(),
				oResourceBundle = this.getResourceBundle(),
				oObject = oView.getModel().getObject(sPath),
				sObjectId = oObject.PageId,
				sObjectName = oObject.PageName,
				oViewModel = this.getModel("detailView");

			this.getOwnerComponent().oListSelector.selectAListItem(sPath);

			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},

		_onMetadataLoaded: function() {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView");

			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			oViewModel.setProperty("/delay", 0);

			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		},

		/**
		 * Set the full screen mode to false and navigate to list page
		 */
		onCloseDetailPress: function() {
			// this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", false);
			// this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/closeColumn", false);
			// // No item should be selected on list after detail page is closed
			// this.getRouter().navTo("Infolist");
			// //this.getOwnerComponent().oListSelector.clearMasterListSelection();
			//this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", false);
			// No item should be selected on list after detail page is closed
			//this.getOwnerComponent().oListSelector.clearListListSelection();
			//this.getRouter().navTo("list");
			this.getModel("appView").setProperty("/layout", "OneColumn");
			this.getRouter().navTo("Infolist", {});

		},

		/**
		 * Toggle between full and non full screen mode.
		 */
		_onExpandButtonPress: function() {
			var bFullScreen = this.getModel("appView").getProperty("/actionButtonsInfo/midColumn/fullScreen");
			this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", !bFullScreen);
			if (!bFullScreen) {
				// store current layout and go full screen
				this.getModel("appView").setProperty("/previousLayout", this.getModel("appView").getProperty("/layout"));
				this.getModel("appView").setProperty("/layout", "MidColumnFullScreen");
			} else {
				// reset to previous layout
				this.getModel("appView").setProperty("/layout", this.getModel("appView").getProperty("/previousLayout"));
			}
		},

		onDeleteInfoPage: function() {
			var that = this;
			var oViewModel = this.getModel("detailView"),
				sPath = this.getView().getElementBinding().getPath(),
				sObjectHeader = this._oODataModel.getProperty(sPath + "/PageName"),
				//sQuestion = this.getResourceBundle.getText("deleteText", sObjectHeader),
				//sSuccessMessage = this.getResourceBundle.getText("deleteSuccess", sObjectHeader);

				sQuestion = "The item " + sObjectHeader + " will be deleted",
				sSuccessMessage = sObjectHeader + " has been deleted";

			var fnMyAfterDeleted = function() {
				MessageBox.show(sSuccessMessage);
				oViewModel.setProperty("/busy", false);
				that.oRouter.navTo("list", {});
				//var oNextItemToSelect = that.getOwnerComponent().oListSelector.findNextItem(sPath);
				//that.getModel("appView").setProperty("/itemToSelect", oNextItemToSelect.getBindingContext().getPath()); //save last deleted
			};
			this._confirmDeletionByUser({
				question: sQuestion
			}, [sPath], fnMyAfterDeleted);
		},
		/* eslint-disable */ // using more then 4 parameters for a function is justified here
		_confirmDeletionByUser: function(oConfirmation, aPaths, fnAfterDeleted, fnDeleteCanceled, fnDeleteConfirmed) {
			/* eslint-enable */
			// Callback function for when the user decides to perform the deletion
			var fnDelete = function() {
				// Calls the oData Delete service
				this._callDelete(aPaths, fnAfterDeleted);
			}.bind(this);

			// Opens the confirmation dialog
			MessageBox.show(oConfirmation.question, {
				icon: oConfirmation.icon || MessageBox.Icon.WARNING,
				title: oConfirmation.title,
				actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
				onClose: function(oAction) {
					if (oAction === MessageBox.Action.OK) {
						fnDelete();
					} else if (fnDeleteCanceled) {
						fnDeleteCanceled();
					}
				}
			});
		},
		/**
		 * Performs the deletion of a list of entities.
		 * @param {array} aPaths -  Array of strings representing the context paths to the entities to be deleted. Currently only one is supported.
		 * @param {callback} fnAfterDeleted (optional) - called after deletion is done. 
		 * @return a Promise that will be resolved as soon as the deletion process ended successfully.
		 * @function
		 * @private
		 */
		_callDelete: function(aPaths, fnAfterDeleted) {
			var oViewModel = this.getModel("detailView");
			oViewModel.setProperty("/busy", true);
			var fnFailed = function() {
				this._oODataModel.setUseBatch(true);
			}.bind(this);
			var fnSuccess = function() {
				if (fnAfterDeleted) {
					fnAfterDeleted();
					this._oODataModel.setUseBatch(true);
				}
				oViewModel.setProperty("/busy", false);
			}.bind(this);
			return this._deleteOneEntity(aPaths[0], fnSuccess, fnFailed);
		},
		_deleteOneEntity: function(sPath, fnSuccess, fnFailed) {
			var oPromise = new Promise(function(fnResolve, fnReject) {
				this._oODataModel.setUseBatch(false);
				this._oODataModel.remove(sPath, {
					success: fnResolve,
					error: fnReject,
					async: true
				});
			}.bind(this));
			oPromise.then(fnSuccess, fnFailed);
			return oPromise;
		},
		onInfoPageSaveData: function() {
			/*var oPayload = {
				"PageName": this.getView().byId("idPageName").getValue(),
				"Url": this.getView().byId("idURL").getValue(),

				"Active": (this.getView().byId("idActive").getSelected() == true ? "X" : "X"),

				"PageDescr": this.getView().byId("idPageDescr").getValue()
					//"CreatedBy" : "E884886"
			};

			//var aInputControls = this._getFormFields(this.byId("idFormNonEditable"));
			this.getModel().create('/INFOPAGESet', oPayload, null, function() {
				alert("Create successful");
			}, function() {
				alert("Create failed");
			});*/

			var oPayload = {
				"PageName": this.getView().byId("idPageName").getValue(),
				"Url": this.getView().byId("idURL").getValue(),

				"Active": (this.getView().byId("idActive").getSelected() == true ? "X" : ""),

				"PageDescr": this.getView().byId("idPageDescr").getValue()
					//"CreatedBy" : "E834441"
			};
			var sError = "Error PageName";
			if (!(oPayload.PageName && oPayload.Url && oPayload.Active && oPayload.PageDescr)) {

				if (!(oPayload.PageName)) {
					MessageBox.show("Short Name field is empty", {
						icon: MessageBox.Icon.WARNING
					});
				} else if (!(oPayload.Url)) {
					MessageBox.show("URL field is empty", {
						icon: MessageBox.Icon.WARNING
					});
				} else if (!(oPayload.Active)) {
					MessageBox.show("Active is not checked", {
						icon: MessageBox.Icon.WARNING
					});
				} else if (!(oPayload.PageDescr)) {
					MessageBox.show("Description field is empty", {
						icon: MessageBox.Icon.WARNING
					});
				}
			}
		},
		onInfoPageSave: function() {
			var PageName = this.getView().byId("idPageName").getValue();
			var Url = this.getView().byId("idURL").getValue();
			var Active = this.getView().byId("idActive").getSelected();
			var PageDesc = this.getView().byId("idPageDescr").getValue();
			var oFileUploader = this.getView().byId("fileUploader").oFileUpload.files;

			if ((PageName == "") || (PageDesc == "")) {
				MessageBox.error("Please fill all mandatory fields...");

			} else if ((Url == "")) {
				MessageBox.error("Please fill URL");
			} else {
				var oPayload = {
					"PageName": PageName,
					"Url": Url,
					"Active": (this.getView().byId("idActive").getSelected() == true ? "X" : ""),
					"PageDescr": PageDesc,
					"INFOPAGETOADD": []

				};
				var that = this;
				this.getModel().create('/INFOPAGESet', oPayload, {
						success: function(oData, response) {
							if (response.headers["sap-message"]) {
								var hdrMessage = response.headers["sap-message"];
								var hdrMessageObject = JSON.parse(hdrMessage);
								MessageBox.error(hdrMessageObject.message);
							} else {
								MessageBox.success("Info Page Created Successfully");
								that.getRouter().navTo("Infolist");

							}

						},
						error: function() {
							// Error
							MessageBox.error("Info Page group Creation failed");
						}
					}

				);
				// this.onDisplayInfoPage();
			}
		},
		onInfoPageUpdate: function() {

			var PageName = this.getView().byId("idPageName").getValue();
			var Url = this.getView().byId("idURL").getValue();
			var Active = this.getView().byId("idActive").getSelected();
			var PageDesc = this.getView().byId("idPageDescr").getValue();
			if ((PageName == "") || (PageDesc == "")) {
				MessageBox.error("Please fill all mandatory fields...");

			} else if ((Url == "")) {
				MessageBox.error("Please fill URL");
			} else {
				var oPayload = {
					"PageId": this.getView().byId("idPageId").getValue(),
					"PageDocId": this.getView().byId("idPageDocId").getValue(),
					"PageName": PageName,
					"Url": Url,
					"Active": (this.getView().byId("idActive").getSelected() == true ? "X" : ""),
					"PageDescr": PageDesc,
					"INFOPAGETOADD": []

				};
				var that = this;
				this.getModel().create('/INFOPAGESet', oPayload, {
					success: function(oData, response) {
						if (response.headers["sap-message"]) {
							var hdrMessage = response.headers["sap-message"];
							var hdrMessageObject = JSON.parse(hdrMessage);
							MessageBox.error(hdrMessageObject.message);
						} else {
							MessageBox.success("Info page updated Successfully");
							that.getRouter().navTo("Infolist");

						}

					},
					error: function() {
						// Error
						MessageBox.error("Info page updation failed");
					}
				});
				//this.onDisplayInfoPage();
			}
		},

		onEditToggleButtonPress: function(oEvent) {
			this.getView().byId("idFormInfoEditable").setVisible(false);
			this.getView().byId("idFormInfoNonEditable").setVisible(true);
			this.getView().byId("idInfoEdit").setVisible(false);
			this.getView().byId("idInfoUpdate").setVisible(true);
			this.getView().byId("idInfoSave").setVisible(false);
			this.getView().byId("idInfoDisplay").setVisible(true);
			this.getView().byId("idUploadUpdate").setVisible(true);
			this.getView().byId("idUploadCreate").setVisible(false);
			this.getView().byId("fileUploader").setValue("");

			// var oObjectPage = this.getView().byId("ObjectPageLayout"),
			// 	bCurrentShowFooterState = oObjectPage.getShowFooter();

			// oObjectPage.setShowFooter(!bCurrentShowFooterState);
		},

		onDisplayInfoPage: function() {
			this.getView().byId("idFormInfoEditable").setVisible(true);
			this.getView().byId("idFormInfoNonEditable").setVisible(false);
			this.getView().byId("idInfoEdit").setVisible(true);
			this.getView().byId("idInfoSave").setVisible(false);
			this.getView().byId("idInfoUpdate").setVisible(false);
			this.getView().byId("idInfoDisplay").setVisible(false);
			this.getView().byId("idattachmentPage").setVisible(true);

		},

		onCreateNewInfoPage: function() {
			this.getView().byId("idFormInfoEditable").setVisible(false);
			this.getView().byId("idFormInfoNonEditable").setVisible(true);
			this.getView().byId("idInfoEdit").setVisible(false);
			this.getView().byId("idInfoSave").setVisible(true);
			this.getView().byId("idInfoUpdate").setVisible(false);
			this.getView().byId("idPageName").setValue("");
			this.getView().byId("idPageDescr").setValue("");
			this.getView().byId("idActive").setSelected(false);
			this.getView().byId("idURL").setValue("");
			this.getView().byId("idattachmentPage").setVisible(false);
			this.getView().byId("idUploadUpdate").setVisible(false);
			this.getView().byId("idUploadCreate").setVisible(true);
			this.getView().byId("fileUploader").setValue("");

		},

		onCreateAttachment: function() {
			var PageName = this.getView().byId("idPageName").getValue();
			var Url = this.getView().byId("idURL").getValue();
			var Active = this.getView().byId("idActive").getSelected();
			var PageDesc = this.getView().byId("idPageDescr").getValue();
			var oFileUploader = this.getView().byId("fileUploader");
			var aContexts = oFileUploader.oFileUpload.files;
			var that = this;
			that._onMultiplAttach = [];

			if ((PageName == "") || (PageDesc == "")) {
				MessageBox.error("Please fill all mandatory fields...");

			} else {

				var oFileUpload = this.getView().byId("fileUploader");

				var domRef = oFileUpload.getFocusDomRef();
				var file = aContexts[0];

				this.fileName = this.getView().byId("fileUploader").getValue();
				//this.fileType = file.type;
				var x = jQuery.sap.domById(oFileUpload.getId() + "-fu").files[0];

				for (var i = 0; i < aContexts.length; i++) {
					var base64 = 'data:' + aContexts[i].type + ';base64,';
					var fname = aContexts[i].name;
					var reader = new FileReader();
					reader.onload = function(e, i) {
						var vContentindex = e.currentTarget.result.indexOf(base64) + base64.length;
						var VContent = e.currentTarget.result.substring(vContentindex);
						that._onMultiplAttach.push({
							"FileName": fname,
							"Content": VContent
						});

						var oPayload = {
							"PageName": PageName,
							"Url": Url,
							"Active": (Active == true ? "X" : ""),
							"PageDescr": PageDesc,
							"INFOPAGETOADD": that._onMultiplAttach

						};

						if (that._onMultiplAttach.length > 0) {
							that.getModel().create("/INFOPAGESet", oPayload, {
								success: function(oData, response) {

									if (response.headers["sap-message"]) {
										var hdrMessage = response.headers["sap-message"];
										var hdrMessageObject = JSON.parse(hdrMessage);
										MessageBox.error(hdrMessageObject.message);
									} else {
										MessageBox.success(" Attachment Created Successfully");
										that.onDisplayInfoPage();
									}
									// SuccessoPayload

								},
								error: function(oError) {
									// Error
									MessageBox.error(" AttachmentCreation failedy");

								}
							});

						}

					};

				}

				reader.readAsDataURL(file);

			}

		},

		onUpdateAttachment: function() {
			var PageId = this.getView().byId("idPageId").getValue();
			var PagedocID = this.getView().byId("idPagedocID").getValue();

			var PageName = this.getView().byId("idPageName").getValue();
			var Url = this.getView().byId("idURL").getValue();
			var Active = this.getView().byId("idActive").getSelected();
			var PageDesc = this.getView().byId("idPageDescr").getValue();
			var oFileUploader = this.getView().byId("fileUploader");
			var aContexts = oFileUploader.oFileUpload.files;
			var that = this;
			that._onMultiplAttach = [];

			if ((PageName == "") || (PageDesc == "")) {
				MessageBox.error("Please fill all mandatory fields...");

			} else {

				var oFileUpload = this.getView().byId("fileUploader");

				var domRef = oFileUpload.getFocusDomRef();
				var file = aContexts[0];

				this.fileName = this.getView().byId("fileUploader").getValue();
				//this.fileType = file.type;
				var x = jQuery.sap.domById(oFileUpload.getId() + "-fu").files[0];

				for (var i = 0; i < aContexts.length; i++) {
					var base64 = 'data:' + aContexts[i].type + ';base64,';
					var fname = aContexts[i].name;
					var reader = new FileReader();
					reader.onload = function(e, i) {
						var vContentindex = e.currentTarget.result.indexOf(base64) + base64.length;
						var VContent = e.currentTarget.result.substring(vContentindex);
						that._onMultiplAttach.push({
							"FileName": fname,
							"Content": VContent
						});

						var oPayload = {
							"PageId": PageId,
							"PageName": PageName,
							"PageDocId": PagedocID,
							"Url": Url,
							"Active": (Active == true ? "X" : ""),
							"PageDescr": PageDesc,
							"INFOPAGETOADD": that._onMultiplAttach

						};

						if (that._onMultiplAttach.length > 0) {
							that.getModel().create("/INFOPAGESet", oPayload, {
								success: function(oData, response) {

									if (response.headers["sap-message"]) {
										var hdrMessage = response.headers["sap-message"];
										var hdrMessageObject = JSON.parse(hdrMessage);
										MessageBox.error(hdrMessageObject.message);
									} else {
										MessageBox.success(" Attachment Created Successfully");
										that.onDisplayInfoPage();
									}
									// SuccessoPayload

								},
								error: function(oError) {
									// Error
									MessageBox.error(" AttachmentCreation failedy");

								}
							});

						}

					};

				}

				reader.readAsDataURL(file);

			}

		},

		onRemoveAttachment: function(e) {

			var PageId = this.getView().byId("idPageId").getValue();
			var PagedocID = this.getView().byId("idPagedocID").getValue();

			var PageName = this.getView().byId("idPageName").getValue();
			var PageDesc = this.getView().byId("idPageDescr").getValue();

			var oPayload = {
				"PageId": PageId,
				"PageName": PageName,
				"PageDocId": PagedocID,
				"Active": "X",
				"PageDescr": PageDesc,

				"INFOPAGETODEL": [{
					"FileName": e.getSource().getProperty("fileName")
				}]

			};

			this.getModel().create("/INFOPAGESet", oPayload, {
				success: function(oData, oResponse) {

				},
				error: function(oError) {

				}
			});

		},

		fieluploadnewcode: function() {
			var oFileUploader = this.getView().byId("fileUploader");
			this.ACITCModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZFILE_SRV");
			https: //dldmz03gwd02.avangrid.net:44300/sap/opu/odata/sap/ZFILE_SRV/FileSet(FileName=%27Material%27)/$value;
				var url = "/FileSet(FileName='" + oFileUploader.getValue() + "')";
			this.ACITCModel.update(url, function() {
				alert("Create successful");
			}, function() {
				alert("Create failed");
			});

		},

		uploadnew: function() {
			var oFileUpload = this.getView().byId("fileUploader");

			var domRef = oFileUpload.getFocusDomRef();
			var file = domRef.files[0];
			var that = this;

			this.fileName =
				this.getView().byId("fileUploader").getValue();
			this.fileType = file.type;

			var reader = new FileReader();
			reader.onload = function(e) {
				var vContent = e.currentTarget.result;

				that.updateFile(that.fileName, that.fileType, vContent);
			};
			reader.readAsDataURL(file);
		},
		onDisplayModeToggleButtonPress: function() {
			this.getView().byId("idInfoEdit").setVisible(true);
			this.getView().byId("idInfoDisplay").setVisible(false);
			this.getView().byId("idFormInfoEditable").setVisible(true);
			this.getView().byId("idFormInfoNonEditable").setVisible(false);
			this.getView().byId("idInfoUpdate").setVisible(false);

		},
		onNavBack: function() {

			this.getModel("appView").setProperty("/layout", "OneColumn");
			this.getRouter().navTo("Infolist", {});
			//this.getOwnerComponent().getRouter().navTo("MessageList", {}, true);

		}

	});

});