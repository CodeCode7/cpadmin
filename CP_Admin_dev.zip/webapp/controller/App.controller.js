sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function(BaseController, JSONModel, Device) {
	"use strict";

	return BaseController.extend("com.avangrid.ui.cpadmin.controller.App", {

		onInit: function() {
			var oViewModel,
				fnSetAppNotBusy,
				iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();

			oViewModel = new JSONModel({
				busy: true,
				delay: 0,
				layout: "OneColumn",
				previousLayout: "",
				actionButtonsInfo: {
					midColumn: {
						fullScreen: false
					}
				}
			});
			this.setModel(oViewModel, "appView");

			fnSetAppNotBusy = function() {
				oViewModel.setProperty("/busy", false);
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			};

			// since then() has no "reject"-path attach to the MetadataFailed-Event to disable the busy indicator in case of an error
			this.getOwnerComponent().getModel().metadataLoaded().then(fnSetAppNotBusy);
			this.getOwnerComponent().getModel().attachMetadataFailed(fnSetAppNotBusy);

			this.getOwnerComponent().getModel().attachRequestSent(function() {

				oViewModel.setProperty("/busy", true);
				oViewModel.setProperty("/delay", 0);
			});
			this.getOwnerComponent().getModel().attachRequestCompleted(function() {
				oViewModel.setProperty("/busy", false);
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});

			// apply content density mode to root view
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
		},
		onItemSelect: function(oEvent) {
			var bReplace = !Device.system.phone;
			// set the layout property of FCL control to show two columns
			var oItem = oEvent.getParameter("item");
			if (oItem.getKey() == "Home") {
				var oToolPage = this.byId("toolPage");
				oToolPage.setSideExpanded(!oToolPage.getSideExpanded());
				this.getModel("appView").setProperty("/layout", "OneColumn");
				this.getRouter().navTo("MessageList", {}, bReplace);
			}

			if (oItem.getKey() == "AlertPage") {

				this.getModel("appView").setProperty("/layout", "OneColumn");
				this.getRouter().navTo("MessageList", {}, bReplace);

			}

			if (oItem.getKey() == "UserMngt") {

				this.getModel("appView").setProperty("/layout", "OneColumn");
				this.getRouter().navTo("list", {}, bReplace);
			}
			if (oItem.getKey() == "PortalPage") {
				this.getModel("appView").setProperty("/layout", "OneColumn");
				this.getRouter().navTo("Infolist", {}, bReplace);

			}
			if (oItem.getKey() == "UserList") {
				this.getModel("appView").setProperty("/layout", "OneColumn");
				this.getRouter().navTo("UserList", {}, bReplace);

			}

			// 	if (oItem.getKey() == "PortalPage") {
			// 	this.oRouter.navTo("InfoPage", {
			// 		layout: "OneColumn"
			// 	});
			// }

		}

	});
});