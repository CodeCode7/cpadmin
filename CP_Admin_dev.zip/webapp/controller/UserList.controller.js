sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/ui/model/FilterOperator',
	"./BaseController",
	"sap/m/library",
	"sap/ui/core/Fragment",
	'sap/ui/table/TablePersoController',
	"sap/ui/model/Sorter",
	'sap/ui/model/Filter',
	"../model/formatter"
], function(Controller, FilterOperator, BaseController, mobileLibrary, Fragment, TablePersoController, Filter, Sorter, formatter) {
	"use strict";
	var ResetAllMode = mobileLibrary.ResetAllMode;
	var Variants;
	return BaseController.extend("com.avangrid.ui.cpadmin.controller.UserList", {
		formatter: formatter,
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.avangrid.ui.cpadmin.view.UserList
		 */
		onInit: function() {
			this.UserTable = this.oView.byId("idUserTable");
			// Peronalisation from ushell service to persist the settings
			if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {

				var oComponent = sap.ui.core.Component.getOwnerComponentFor(this.getView());
				this.oPersonalizationService = sap.ushell.Container.getService("Personalization");
				var oPersId = {
					container: "TablePersonalisation",
					item: "idUserTable"
				};
				// define scope 
				var oScope = {
					keyCategory: this.oPersonalizationService.constants.keyCategory.FIXED_KEY,
					writeFrequency: this.oPersonalizationService.constants.writeFrequency.LOW,
					clientStorageAllowed: true
				};
				// Get a Personalizer
				var oPersonalizer = this.oPersonalizationService.getPersonalizer(oPersId, oScope, oComponent);
				this.oPersonalizationService.getContainer("TablePersonalisation", oScope, oComponent)
					.fail(function() {})
					.done(function(oContainer) {
						this.oContainer = oContainer;
						this.oVariantSetAdapter = new sap.ushell.services.Personalization.VariantSetAdapter(this.oContainer);
						// get variant set which is stored in backend
						this.oVariantSet = this.oVariantSetAdapter.getVariantSet("idUserTable");
						if (!this.oVariantSet) { //if not in backend, then create one
							this.oVariantSet = this.oVariantSetAdapter.addVariantSet("idUserTable");
						}
						// array to store the existing variants
						Variants = [];
						// now get the existing variants from the backend to show as list
						for (var key in this.oVariantSet.getVariantNamesAndKeys()) {
							if (this.oVariantSet.getVariantNamesAndKeys().hasOwnProperty(key)) {
								var oVariantItemObject = {};
								oVariantItemObject.Key = this.oVariantSet.getVariantNamesAndKeys()[key];
								oVariantItemObject.Name = key;
								Variants.push(oVariantItemObject);
							}
						}
						// create JSON model and attach to the variant management UI control
						this.oVariantModel = new sap.ui.model.json.JSONModel();
						this.oVariantModel.oData.Variants = Variants;
						this.getView().byId("Variants").setModel(this.oVariantModel, "VariantsModel");
					}.bind(this));
				// create table persco controller
				this.oTablepersoService = new TablePersoController({
					table: this.getView().byId("idUserTable"),
					persoService: oPersonalizer
				});

			}
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.avangrid.ui.cpadmin.view.UserList
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.avangrid.ui.cpadmin.view.UserList
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.avangrid.ui.cpadmin.view.UserList
		 */
		//	onExit: function() {
		//
		//	}

		onSearch: function(oEvent) {
			var oTableSearchState = [],
				sQuery = oEvent.getParameter("query");

			if (sQuery && sQuery.length > 0) {
				oTableSearchState = [new Filter("UseridPat", FilterOperator.Contains, sQuery)];
			}

			this.UserTable.getBinding("rows").filter(oTableSearchState, "Application");
		},

		onListItemPress: function(oEvent) {

			var oRow = oEvent.getParameter("row");
			var oItem = oEvent.getParameter("item");

			//this.getView().getModel().getProperty("ConUname", oRow.getBindingContext());

			//var MessObj = oEvent.getSource().getBindingContext().getProperty("MessId");
			//	var	MessObj = oEvent.getSource().getBindingContext().getPath();
			var ConUname = this.getView().getModel().getProperty("ConUname", oRow.getBindingContext());
			// oNextUIState;

			// set the layout property of FCL control to show two columns
			this.getModel("appView").setProperty("/layout", "OneColumn");
			this.getRouter().navTo("UserDetail", {
				ConUname: ConUname
			});

			// this.getOwnerComponent().getHelper().then(function(oHelper) {
			// 	oNextUIState = oHelper.getNextUIState(1);
			// 	this.oRouter.navTo("detail", {
			// 		layout: oNextUIState.layout,
			// 		product: product
			// 	});
			// }.bind(this));
		},

		onSort: function() {
			var oView = this.getView();
			if (!this.byId("sortDialog")) {
				Fragment.load({
					id: oView.getId(),
					name: "com.avangrid.ui.cpadmin.fragments.UserListSortDialog",
					controller: this
				}).then(function(oDialog) {
					oView.addDependent(oDialog);
					oDialog.open();
				});
			} else {
				this.byId("sortDialog").open();
			}
		},
		handleSortDialogConfirm: function(oEvent) {
			var oTable = this.byId("idUserTable"),
				mParams = oEvent.getParameters(),
				oBinding = oTable.getBinding("rows"),
				sPath,
				bDescending,
				aSorters = [];

			sPath = mParams.sortItem.getKey();
			bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending));
			// apply the selected sort and group settings
			oBinding.sort(aSorters);
			
		},

		onPersoButtonPressed: function(oEvent) {
			this.oTablepersoService.openDialog({
				ok: "this.onPerscoDonePressed.bind(this)"
			});
			this._waitForDialog(this);
		},
		_waitForDialog: function(that) {
			if (typeof that.oTablepersoService._oDialog !== "undefined") {
				that.oTablepersoService._oDialog.attachConfirm(that, that.onPerscoDonePressed.bind(that));
			} else {
				setTimeout(this._waitForDialog, 250, that);
			}
		},
		onPerscoDonePressed: function(oEvent) {
			this.oTablepersoService.savePersonalizations();
		},
		onSaveAs: function(oEvent) {
			// get variant parameters:
			var VariantParam = oEvent.getParameters();
			// get columns data: 
			var aColumnsData = [];
			this.getView().byId("idUserTable").getColumns().forEach(function(oColumn, index) {
				var aColumn = {};
				aColumn.fieldName = oColumn.getProperty("name");
				aColumn.Id = oColumn.getId();
				aColumn.index = index;
				aColumn.Visible = oColumn.getVisible();
				aColumnsData.push(aColumn);
			});

			this.oVariant = this.oVariantSet.addVariant(VariantParam.name);
			if (this.oVariant) {
				this.oVariant.setItemValue("ColumnsVal", JSON.stringify(aColumnsData));
				if (VariantParam.def === true) {
					this.oVariantSet.setCurrentVariantKey(this.oVariant.getVariantKey());
				}
				this.oContainer.save().done(function() {
					// Tell the user that the personalization data was saved
				});
			}
		},
		onSelect: function(oEvent) {
			var selectedKey = oEvent.getParameters().key;
			for (var i = 0; i < oEvent.getSource().getVariantItems().length; i++) {
				if (oEvent.getSource().getVariantItems()[i].getProperty("key") === selectedKey) {
					var selectedVariant = oEvent.getSource().getVariantItems()[i].getProperty("text");
					break;
				}
			}
			this._setSelectedVariantToTable(selectedVariant);
		},

		_setSelectedVariantToTable: function(oSelectedVariant) {
			if (oSelectedVariant) {
				var sVariant = this.oVariantSet.getVariant(this.oVariantSet.getVariantKeyByName(oSelectedVariant));
				var aColumns = JSON.parse(sVariant.getItemValue("ColumnsVal"));

				// Hide all columns first
				this.getView().byId("idUserTable").getColumns().forEach(function(oColumn) {
					oColumn.setVisible(false);
				});
				// re-arrange columns according to the saved variant

				aColumns.forEach(function(aColumn) {
					var aTableColumn = $.grep(this.getView().byId("idUserTable").getColumns(), function(el, id) {
						return el.getProperty("name") === aColumn.fieldName;
					});
					if (aTableColumn.length > 0) {
						aTableColumn[0].setVisible(aColumn.Visible);
						this.getView().byId("idUserTable").removeColumn(aTableColumn[0]);
						this.getView().byId("idUserTable").insertColumn(aTableColumn[0], aColumn.index);
					}
				}.bind(this));
			}
			// null means the standard variant is selected or the variant which is not available, then show all columns
			else {
				this.getView().byId("idUserTable").getColumns().forEach(function(oColumn) {
					oColumn.setVisible(true);
				});
			}
		},
		onManage: function(oEvent) {
			var aParameters = oEvent.getParameters();
			// rename variants
			if (aParameters.renamed.length > 0) {
				aParameters.renamed.forEach(function(aRenamed) {
					var sVariant = this.oVariantSet.getVariant(aRenamed.key),
						sItemValue = sVariant.getItemValue("ColumnsVal");
					// delete the variant 
					this.oVariantSet.delVariant(aRenamed.key);
					// after delete, add a new variant
					var oNewVariant = this.oVariantSet.addVariant(aRenamed.name);
					oNewVariant.setItemValue("ColumnsVal", sItemValue);
				}.bind(this));
			}
			// default variant change
			if (aParameters.def !== "*standard*") {
				this.oVariantSet.setCurrentVariantKey(aParameters.def);
			} else {
				this.oVariantSet.setCurrentVariantKey(null);
			}
			// Delete variants
			if (aParameters.deleted.length > 0) {
				aParameters.deleted.forEach(function(aDelete) {
					this.oVariantSet.delVariant(aDelete);
				}.bind(this));
			}
			//  Save the Variant Container
			this.oContainer.save().done(function() {
				// Tell the user that the personalization data was saved
			});
		},
		onExportUserInfo: function() {
			var sUrl = "/sap/opu/odata/sap/ZADMIN_PORTAL_SRV/USERLISTSet?$format=xlsx";
			var encodeUrl = encodeURI(sUrl);
			sap.m.URLHelper.redirect(encodeUrl, false);
		},
		
		onRefresh:function(){
				this.getView().byId("idUserTable").getBinding("rows").refresh();
		}

	});

});