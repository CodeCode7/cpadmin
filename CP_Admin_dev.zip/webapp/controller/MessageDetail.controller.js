sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"../model/formatter",
	"sap/ui/model/json/JSONModel",
	"./BaseController",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Filter",
	"sap/m/MessageBox",
	"sap/ui/core/routing/History"
], function(Controller, formatter, JSONModel, BaseController, FilterOperator, Filter, MessageBox, History) {
	"use strict";

	return BaseController.extend("com.avangrid.ui.cpadmin.controller.MessageDetail", {

		formatter: formatter,
		onInit: function() {

			this.getRouter().getTargets().getTarget("MeaasgeobjectEmpty").attachDisplay(null, this._onDisplay, this);
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var oViewMsgDetailModel = new JSONModel({
				busy: false,
				delay: 0,
				minDate: new Date()
			});

			this._oPayload = {};
			this._oPayload.MessageToUser = [];
			this._userGroupkeys = [];

			this.oOwnerComponent = this.getOwnerComponent();

			this.oRouter = this.oOwnerComponent.getRouter();
			this.oModel = this.oOwnerComponent.getModel();
			this._oODataModel = this.getOwnerComponent().getModel();

			this.oRouter.getRoute("Meaasgeobject").attachPatternMatched(this._onProductMatched, this);
			this.setModel(oViewMsgDetailModel, "MsgdetailView");
			this.byId("DP1").setMinDate(new Date());
			this.byId("DP2").setMinDate(new Date());
			// this.oRouter.getRoute("detail").attachPatternMatched(this._onProductMatched, this);
			// this.oRouter.getRoute("detailDetail").attachPatternMatched(this._onProductMatched, this);
			var DP1 = this.byId("DP1");
			DP1.addDelegate({
				onAfterRendering: function() {
					DP1.$().find('INPUT').attr('disabled', true);
				}
			}, DP1);

			var DP2 = this.byId("DP2");
			DP2.addDelegate({
				onAfterRendering: function() {
					DP2.$().find('INPUT').attr('disabled', true);
				}
			}, DP2);
		},

		onSupplierPress: function(oEvent) {
			var supplierPath = oEvent.getSource().getBindingContext("products").getPath(),
				supplier = supplierPath.split("/").slice(-1).pop(),
				oNextUIState;

			this.oOwnerComponent.getHelper().then(function(oHelper) {
				oNextUIState = oHelper.getNextUIState(2);
				this.oRouter.navTo("detailDetail", {
					layout: oNextUIState.layout,
					supplier: supplier,
					product: this._product
				});
			}.bind(this));
		},

		_onProductMatched: function(oEvent) {
			// this._product = oEvent.getParameter("arguments").objectId || this._product || "0";
			// 	// var sObjectPath = this.getModel().createKey("MESSAGESet", this._product);
			// 	// this._bindView("/" + sObjectPath);
			// 	var	path="/MESSAGESet('"+this._product+"')";
			// this.getView().bindElement(path);
			var sObjectId = oEvent.getParameter("arguments").objectId;
			this.getModel("appView").setProperty("/layout", "OneColumn");
			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey("MessageSet", {
					MessId: sObjectId
				});
				this.getView().bindElement("/" + sObjectPath);
				this.onSelectMultiUser();
			}.bind(this));
		},

		onEditToggleButtonPress: function(oEvent) {
			this.getView().byId("idFormEditable").setVisible(false);
			this.getView().byId("idFormNonEditable").setVisible(true);
			this.getView().byId("idMsgEdit").setVisible(false);
			this.getView().byId("idMsgUpdate").setVisible(true);
			this.getView().byId("idMsgSaveAsTemplate").setVisible(false);
			this.getView().byId("idMsgDisplay").setVisible(true);
			this.onSelectMultiUser();

			// var oObjectPage = this.getView().byId("ObjectPageLayout")
			// 	bCurrentShowFooterState = oObjectPage.getShowFooter();

			// oObjectPage.setShowFooter(!bCurrentShowFooterState);
		},

		onSelectMultiUser: function() {
			this.getView().byId("messageId").setVisible(true);
			var userKeys = this.getView().byId("multiInputUserId").getTokens();
			var groupKeys = this.getView().byId("multiInputGroupId").getTokens();
			var that = this;
			var userArray = [];
			var groupArray = [];
			if (userKeys) {
				var data = userKeys.map(function(userKey) {
					userArray.push(userKey.getText());

				});
			}
			if (groupKeys) {
				var data1 = groupKeys.map(function(groupKey) {
					groupArray.push(groupKey.getKey());

				});
			}
			that.getView().byId("idConUname").setSelectedKeys(userArray);
			that.getView().byId("idGroupName").setSelectedKeys(groupArray);

		},
		onDisplayModeToggleButtonPress: function() {
			this.getView().byId("idMsgEdit").setVisible(true);
			this.getView().byId("idMsgDisplay").setVisible(false);
			this.getView().byId("idFormEditable").setVisible(true);
			this.getView().byId("idFormNonEditable").setVisible(false);
			this.getView().byId("idMsgUpdate").setVisible(false);
			this.getView().byId("idMsgSaveAsTemplate").setVisible(false);

		},

		handleFullScreen: function() {
			var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/fullScreen");
			this.oRouter.navTo("detail", {
				layout: sNextLayout,
				product: this._product
			});
		},

		handleExitFullScreen: function() {
			var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/exitFullScreen");
			this.oRouter.navTo("detail", {
				layout: sNextLayout,
				product: this._product
			});
		},

		/**
		 * Toggle between full and non full screen mode.
		 */
		toggleFullScreen: function() {
			var bFullScreen = this.getModel("appView").getProperty("/actionButtonsInfo/midColumn/fullScreen");
			this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", !bFullScreen);
			if (!bFullScreen) {
				// store current layout and go full screen
				this.getModel("appView").setProperty("/previousLayout", this.getModel("appView").getProperty("/layout"));
				this.getModel("appView").setProperty("/layout", "MidColumnFullScreen");
			} else {
				// reset to previous layout
				this.getModel("appView").setProperty("/layout", this.getModel("appView").getProperty("/previousLayout"));
			}
		},

		handleClose: function() {
			var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/closeColumn");
			this.oRouter.navTo("master", {
				layout: sNextLayout
			});
		},

		onExit: function() {
			// this.oRouter.getRoute("master").detachPatternMatched(this._onProductMatched, this);
			// this.oRouter.getRoute("detail").detachPatternMatched(this._onProductMatched, this);
		},
		onCloseDetailPress: function() {
			this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/closeColumn", false);
			// No item should be selected on list after detail page is closed
			this.getRouter().navTo("list");
			//this.getOwnerComponent().oListSelector.clearMasterListSelection();

		},
		onMsgSuggest: function(oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = [];
			if (sTerm) {
				aFilters.push(new Filter("TemplName", FilterOperator.Contains, sTerm));
			}

			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);

		},
		_onDisplay: function(oEvent) {
			this.getView().byId("idFormNonEditable").setVisible(true);
			this.getView().byId("idFormEditable").setVisible(false);
			this.getView().byId("templateVisibilityCheck").setVisible(true);
			this.getView().byId("idMessName").setValue("");
			this.getView().byId("idMessageDescription").setValue("");
			this.getView().byId("messageId").setVisible(false);
			this.getView().byId("idConUname").setSelectedKeys('');
			this.getView().byId("idGroupName").setSelectedKeys('');
			this.getView().byId("idAllContractors").setSelected(false);
			this.getView().byId("ReminderId").setSelected(false);
			this.getView().byId("idGroupName").setEditable(true);
			this.getView().byId("idConUname").setEditable(true);
			this.getView().byId("idMsgEdit").setVisible(false);
			this.getView().byId("idMsgDisplay").setVisible(false);
			this.getView().byId("messaageNameVisibilityCheck").setVisible(false);
			this.getView().byId("idMsgSave").setVisible(true);
			var oData = oEvent.getParameter("data");
			if (oData && oData.mode === "update") {
				this._onEdit(oEvent);
			} else {
				//this._onCreate(oEvent);
			}
		},
		_onCreate: function(oEvent) {
			// if (oEvent.getParameter("name") && oEvent.getParameter("name") !== "create") {
			// 	//this._oViewModel.setProperty("/enableCreate", false);
			// 	this.getRouter().getTargets().detachDisplay(null, this._onDisplay, this);
			// 	this.getView().unbindObject();
			// 	return;
			// }

			//this._oViewModel.setProperty("/viewTitle", this.getResourceBundle.getText("createViewTitle"));
			//this._oViewModel.setProperty("/mode", "create");
			var that = this;
			var oContext = this.getOwnerComponent().getModel().createEntry("MESSAGESet", {
				success: that._fnEntityCreated.bind(this),
				error: that._fnEntityCreationFailed.bind(this)
			});
			this.getView().setBindingContext(oContext);
		},
		_fnEntityCreated: function(oData) {
			var sObjectPath = this.getModel().createKey("MESSAGESet", oData);

		},
		_fnEntityCreationFailed: function() {
			this.getModel("appView").setProperty("/busy", false);
		},
		// 	onMessageSave: function(oEvent) {
		// 	this.getView().byId("idMsgEdit").setVisible(true);
		// 	this.getView().byId("idFormEditable").setVisible(true);
		// 	this.getView().byId("idFormNonEditable").setVisible(false);
		// 	this.getView().byId("idMsgSave").setVisible(false);
		// 	this.getView().byId("idMsgSaveAsTemplate").setVisible(false);

		// },
		onMessageSave: function(oEvent) {
			this.getView().byId("idMsgEdit").setVisible(true);
			this.getView().byId("idFormEditable").setVisible(true);
			this.getView().byId("idFormNonEditable").setVisible(false);
			this.getView().byId("idMsgSave").setVisible(false);
			this.getView().byId("idMsgSaveAsTemplate").setVisible(false);
			var that = this,
				oModel = this.getModel();

			//this.getModel("appView").setProperty("/busy", true);
			//if (this._oViewModel.getProperty("/mode") === "edit") {
			// attach to the request completed event of the batch
			oModel.attachEventOnce("batchRequestCompleted", function(oEvent) {
				if (that._checkIfBatchRequestSucceeded(oEvent)) {
					that._fnUpdateSuccess();
				} else {
					that._fnEntityCreationFailed();
					//MessageBox.error(that.getResourceBundle.getText("updateError"));
				}
			});
			//}
			oModel.submitChanges();
		},

		_checkIfBatchRequestSucceeded: function(oEvent) {
			var oParams = oEvent.getParameters();
			var aRequests = oEvent.getParameters().requests;
			var oRequest;
			if (oParams.success) {
				if (aRequests) {
					for (var i = 0; i < aRequests.length; i++) {
						oRequest = oEvent.getParameters().requests[i];
						if (!oRequest.success) {
							return false;
						}
					}
				}
				return true;
			} else {
				return false;
			}
		},
		/**
		 * Handles the success of updating an object
		 * @private
		 */
		_fnUpdateSuccess: function() {
			this.getModel("appView").setProperty("/busy", false);
			//this.getView().unbindObject();
			//this.getRouter().getTargets().display("object");
		},
		onMessageSave2: function() {
			var that = this;
			this.getModel().setDeferredGroups(["linkShipmentGrp"]);

			var oPayload = {
				// ShipmentNumber: this.getModel("oGlobalModel").getProperty("/sShipmentNum"),
				// Port: this.getModel("oShipmentHdrModel").getProperty("/Port"),

				MessName: "Samara",
				ConUname: "E024124",
				MessDescr: "Samara",
				CreatedBy: "E884886"
			};
			this.getModel().callFunction("/ZIU_CP_SAVE_MESSAGE", {
				urlParameters: oPayload,
				method: "POST",
				batchGroupId: "linkShipmentGrp"
			});

			this.getModel().submitChanges({
				batchGroupId: "linkShipmentGrp",
				async: false,
				success: function(oData, oResponse) {
					MessageBox.success("Shipment linked successfully");
					//that.getRouter().navTo("FinalShipment");
				},
				error: function(oError) {
					MessageBox.error("Shipment linking failed");
				}
			});
		},
		onMessageSave1: function() {
			//var tmpModel = new ODataModel("https://xxyyzz.com/sap/opu/odata/<your_service>_SRV/", true);
			this.getModel().setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.getModel().setUseBatch(true);

			this.getModel().setDeferredGroups(["foo"]);
			var mParameters = {
				groupId: "foo",
				success: function(odata, resp) {
					console.log(resp);
				},
				error: function(odata, resp) {
					console.log(resp);
				}
			};
			var oPayload;
			for (var m = 0; m < oPayload.length; m++) {
				this.getModel().update("/MessageSet", oPayload[m], mParameters);
			}
			this.getModel().submitChanges(mParameters);
		},
		onDelete: function() {
			var that = this;
			var oViewModel = this.getModel("MsgdetailView"),
				sPath = this.getView().getElementBinding().getPath(),
				sObjectHeader = this._oODataModel.getProperty(sPath + "/MessName"),
				//sQuestion = this.getResourceBundle.getText("deleteText", sObjectHeader),
				//sSuccessMessage = this.getResourceBundle.getText("deleteSuccess", sObjectHeader);

				sQuestion = "The item " + sObjectHeader + " will be deleted",
				sSuccessMessage = sObjectHeader + " has been deleted";

			var fnMyAfterDeleted = function() {
				MessageBox.show(sSuccessMessage);
				oViewModel.setProperty("/busy", false);
				that.getOwnerComponent().getRouter().navTo("MessageList", {}, true);
				//var oNextItemToSelect = that.getOwnerComponent().oListSelector.findNextItem(sPath);
				//that.getModel("appView").setProperty("/itemToSelect", oNextItemToSelect.getBindingContext().getPath()); //save last deleted
			};
			this._confirmDeletionByUser({
				question: sQuestion
			}, [sPath], fnMyAfterDeleted);
		},
		/* eslint-disable */ // using more then 4 parameters for a function is justified here
		_confirmDeletionByUser: function(oConfirmation, aPaths, fnAfterDeleted, fnDeleteCanceled, fnDeleteConfirmed) {
			/* eslint-enable */
			// Callback function for when the user decides to perform the deletion
			var fnDelete = function() {
				// Calls the oData Delete service
				this._callDelete(aPaths, fnAfterDeleted);
			}.bind(this);

			// Opens the confirmation dialog
			MessageBox.show(oConfirmation.question, {
				icon: oConfirmation.icon || MessageBox.Icon.WARNING,
				title: oConfirmation.title,
				actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
				onClose: function(oAction) {
					if (oAction === MessageBox.Action.OK) {
						fnDelete();
					} else if (fnDeleteCanceled) {
						fnDeleteCanceled();
					}
				}
			});
		},
		/**
		 * Performs the deletion of a list of entities.
		 * @param {array} aPaths -  Array of strings representing the context paths to the entities to be deleted. Currently only one is supported.
		 * @param {callback} fnAfterDeleted (optional) - called after deletion is done. 
		 * @return a Promise that will be resolved as soon as the deletion process ended successfully.
		 * @function
		 * @private
		 */
		_callDelete: function(aPaths, fnAfterDeleted) {
			var oViewModel = this.getModel("MsgdetailView");
			oViewModel.setProperty("/busy", true);
			var fnFailed = function() {
				this._oODataModel.setUseBatch(true);
			}.bind(this);
			var fnSuccess = function() {
				if (fnAfterDeleted) {
					fnAfterDeleted();
					this._oODataModel.setUseBatch(true);
				}
				oViewModel.setProperty("/busy", false);
			}.bind(this);
			return this._deleteOneEntity(aPaths[0], fnSuccess, fnFailed);
		},
		_deleteOneEntity: function(sPath, fnSuccess, fnFailed) {
			var oPromise = new Promise(function(fnResolve, fnReject) {
				this._oODataModel.setUseBatch(false);
				this._oODataModel.remove(sPath, {
					success: fnResolve,
					error: fnReject,
					async: true
				});
			}.bind(this));
			oPromise.then(fnSuccess, fnFailed);
			return oPromise;
		},

		onMultipleUser: function() {
			var mulUser = this.getView().byId("idConUname").getSelectedItems();
			var userid = [];
			for (var i = 0; i < mulUser.length; i++) {
				this._oPayload.MessageToUser.push({
					"UserId": this.getView().byId("idConUname").getSelectedItems()[i].getKey()
				});
			}

		},

		onMultipleGroup: function() {
			var userGroupkeys = this.getView().byId("idGroupName").getSelectedItems();

			for (var j = 0; j < userGroupkeys.length; j++) {
				this._userGroupkeys.push({
					"GroupId": this.getView().byId("idGroupName").getSelectedItems()[j].getKey()
				});
			}

		},

		onMsgSaveCreate: function() {
			this._oPayload.MessageToUser = [];
			this._userGroupkeys = [];
			this.onMultipleUser();
			this.onMultipleGroup();
			var startDate = this.getView().byId("DP1").getDateValue();
			var endDate = this.getView().byId("DP2").getDateValue();

			var Payload = {

				"MessName": this.getView().byId("idMessName").getValue(),
				"MessDescr": this.getView().byId("idMessageDescription").getValue(),
				"AllContractors": (this.getView().byId("idAllContractors").getSelected() == true ? "X" : ""),
				"Active": (this.getView().byId("idActive").getSelected() == true ? "X" : ""),
				"Reminder": (this.getView().byId("ReminderId").getSelected() == true ? "X" : ""),
				"SchStart": startDate,
				"SchEnd": endDate,
				"MessageToUser": this._oPayload.MessageToUser,
				"MessagetoGroup": this._userGroupkeys

			};
			var that = this;
			if (this.messageCreationValidation() == "ok") {
				this.getModel().create('/MessageSet', Payload, {
					success: function(oData, response) {

						if (response.headers["sap-message"]) {
							var hdrMessage = response.headers["sap-message"];
							var hdrMessageObject = JSON.parse(hdrMessage);
							MessageBox.error(hdrMessageObject.message);
						} else {
							MessageBox.success("Message Created Successfully");
							that.afterCreateMsgDisplay();
							that.getOwnerComponent().getRouter().navTo("MessageList", {}, true);
						}

					},
					error: function() {
						// Error
						MessageBox.error("Message Creation failed");
					}
				});

			} else if (this.messageCreationValidation() == "CG") {
				MessageBox.error("Please select at least one Contractor or Group ");
			} else {
				MessageBox.error("Please fill all mandatory fields...");
			}

		},

		afterCreateMsgDisplay: function() {
			this.getView().byId("idFormNonEditable").setVisible(false);
			this.getView().byId("idFormEditable").setVisible(true);
			this.getView().byId("idMsgSave").setVisible(false);
			this.getView().byId("idMsgEdit").setVisible(true);
		},

		_setLocalTimeZoneZone: function(datevalue) {
			if (datevalue !== undefined && datevalue !== null && datevalue !== "") {
				datevalue = new Date(datevalue);
				var offSet = datevalue.getTimezoneOffset();
				var offSetVal = datevalue.getTimezoneOffset() / 60;
				var h = Math.floor(Math.abs(offSetVal));
				var m = Math.floor((Math.abs(offSetVal) * 60) % 60);
				datevalue = new Date(datevalue.setHours(h, m, 0, 0));
				return datevalue;
			}
			return null;
		},
		onMsgUpdate: function() {
			this._oPayload.MessageToUser = [];
			this._userGroupkeys = [];
			this.onMultipleUser();
			this.onMultipleGroup();
			var that = this;
			var startDate = this.getView().byId("DP1").getDateValue();
			var endDate = this.getView().byId("DP2").getDateValue();

			var Payload = {
				"MessId": this.getView().byId("messageIdInput").getValue(),
				"MessName": this.getView().byId("idMessNameInput").getValue(),
				"StName": this.getView().byId("idtxtStName").getText(),
				"SchStart": startDate,
				"SchEnd": endDate,
				"MessDescr": this.getView().byId("idMessageDescription").getValue(),
				"AllContractors": (this.getView().byId("idAllContractors").getSelected() == true ? "X" : ""),
				"Active": (this.getView().byId("idActive").getSelected() == true ? "X" : ""),
				"Reminder": (this.getView().byId("ReminderId").getSelected() == true ? "X" : ""),
				"MessageToUser": this._oPayload.MessageToUser,
				"MessagetoGroup": this._userGroupkeys

			};

			var spath = this.getView().getElementBinding().getPath();

			if (this.messageUpdateValidation() == "ok") {
				this.getModel().create('/MessageSet', Payload, {
					success: function(oData, response) {

						if (response.headers["sap-message"]) {
							var hdrMessage = response.headers["sap-message"];
							var hdrMessageObject = JSON.parse(hdrMessage);
							MessageBox.error(hdrMessageObject.message);
						} else {
							MessageBox.success("Message Updated Successfully");
							that.getOwnerComponent().getRouter().navTo("MessageList", {}, true);
						}

					},
					error: function() {
						// Error
						MessageBox.error("Message Updation failed");
					}
				});
			} else if (this.messageUpdateValidation() == "CG") {
				MessageBox.error("Please select at least one Contractor or Group ");
			} else {
				MessageBox.error("Please fill all mandatory fields...");
			}

		},
		messageCreationValidation: function() {
			var idMessName = this.getView().byId("idMessName");
			var idConUname = this.getView().byId("idConUname");
			var idGroupName = this.getView().byId("idGroupName");
			var idAllContractors = this.getView().byId("idAllContractors");
			var DP1 = this.getView().byId("DP1");
			var DP2 = this.getView().byId("DP2");
			var idMessageDescription = this.getView().byId("idMessageDescription");

			if ((idMessName.getValue() == "") || (idMessageDescription.getValue() == "") || (DP1.getValue() == "") || (DP2.getValue() == "")) {

				return "M";

			} else if ((idConUname.getSelectedKeys() != "") || (idGroupName.getSelectedKeys() != "") || (idAllContractors.getSelected() !=
					false)) {

				return "ok";

			} else {

				return "CG";
			}

		},

		messageUpdateValidation: function() {
			var idMessName = this.getView().byId("idMessNameInput");
			var idConUname = this.getView().byId("idConUname");
			var idGroupName = this.getView().byId("idGroupName");
			var idAllContractors = this.getView().byId("idAllContractors");
			var DP1 = this.getView().byId("DP1");
			var DP2 = this.getView().byId("DP2");
			var idMessageDescription = this.getView().byId("idMessageDescription");

			if ((idMessName.getValue() == "") || (idMessageDescription.getValue() == "") || (DP1.getValue() == "") || (DP2.getValue() == "")) {

				return "M";

			} else if ((idConUname.getSelectedKeys() != "") || (idGroupName.getSelectedKeys() != "") || (idAllContractors.getSelected() !=
					false)) {

				return "ok";

			} else {

				return "CG";
			}

		},
		_getFormFields: function(oSimpleForm) {
			var aControls = [];
			var aFormContent = oSimpleForm.getContent();
			var sControlType;
			for (var i = 0; i < aFormContent.length; i++) {
				sControlType = aFormContent[i].getMetadata().getName();
				if (sControlType === "sap.m.Input" || sControlType === "sap.m.DateTimeInput" ||
					sControlType === "sap.m.CheckBox") {
					aControls.push({
						control: aFormContent[i],
						required: aFormContent[i - 1].getRequired && aFormContent[i - 1].getRequired()
					});
				}
			}
			return aControls;
		},
		mcbUserhandleSelectionChange: function(oEvent) {
			var isSelected = oEvent.getSource().getSelectedKeys();
			var isSelectedVal = oEvent.getParameter("selected");
			if (isSelected.length > 0 && isSelectedVal) {
				this.getView().byId("idGroupName").setEditable(false);
				this.getView().byId("idAllContractors").setEditable(false);
				this.getView().byId("idAllContractors").setSelected(false);
				this.getView().byId("idGroupName").setSelectedKeys("");

			} else {
				this.getView().byId("idGroupName").setEditable(true);
				this.getView().byId("idAllContractors").setEditable(true);

			}
		},

		mcbGrouphandleSelectionChange: function(oEvent) {
			var isSelected = oEvent.getSource().getSelectedKeys();
			var isSelectedVal = oEvent.getParameter("selected");
			if (isSelected.length > 1 && isSelectedVal) {

				this.getView().byId("idConUname").setEditable(false);
				this.getView().byId("idAllContractors").setEditable(false);
				this.getView().byId("idConUname").setSelectedKeys("");
				this.getView().byId("idAllContractors").setSelected(false);

			} else {
				this.getView().byId("idConUname").setEditable(true);
				this.getView().byId("idConUname").setValue("");
				this.getView().byId("idAllContractors").setEditable(true);
				this.getView().byId("idAllContractors").setSelected(false);
			}
		},

		onAllContractorsClicked: function(oEvent) {
			var isSelected = oEvent.getParameter("selected");
			if (isSelected) {
				this.getView().byId("idConUname").setEditable(false);
				this.getView().byId("idGroupName").setEditable(false);
				this.getView().byId("idConUname").setSelectedKeys("");
				this.getView().byId("idGroupName").setSelectedKeys("");

			} else {
				this.getView().byId("idConUname").setEditable(true);
				this.getView().byId("idGroupName").setEditable(true);

			}
		},
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash();

			// if (sPreviousHash !== undefined) {
			// 	history.go(-1);
			// } else {

			this.getOwnerComponent().getRouter().navTo("MessageList", {}, true);
			//}
		},

		handleDP1Change: function(oEvent) {
			if (this.byId("DP1").isValidValue()) {
				this.byId("DP2").setMinDate(this.byId("DP1").getDateValue());
				this.byId("DP1").setMinDate(new Date());
			} else {
				this.byId("DP1").setMinDate(new Date());
				this.byId("DP2").setMinDate(new Date());
			}

		},
		handleDP2Change: function() {
			if (this.byId("DP2").isValidValue()) {
				this.byId("DP1").setMaxDate(this.byId("DP2").getDateValue());
				this.byId("DP2").setMinDate(new Date());
			} else {
				this.byId("DP1").setMinDate(new Date());
				this.byId("DP2").setMinDate(new Date());
			}
		}

	});
});