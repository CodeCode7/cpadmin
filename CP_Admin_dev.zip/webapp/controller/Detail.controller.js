sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"sap/m/library",
	"sap/ui/core/Fragment",
	'sap/ui/table/TablePersoController',
	'../model/UserTableFunc',
	'sap/ui/model/Filter',
	"sap/ui/model/Sorter",
	'sap/ui/model/FilterOperator',
	'sap/m/MessageToast',
	"sap/m/MessageBox",
	"sap/ui/core/routing/History"
], function(BaseController, JSONModel, formatter, mobileLibrary, Fragment, TablePersoController, UserTableFunc, Filter, Sorter,
	FilterOperator, MessageToast, MessageBox, History) {
	"use strict";
	var ResetAllMode = mobileLibrary.ResetAllMode;
	var Variants;
	// shortcut for sap.m.URLHelperHistory
	var URLHelper = mobileLibrary.URLHelper;

	return BaseController.extend("com.avangrid.ui.cpadmin.controller.Detail", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0
			});
			//this.getRouter().getTargets().getTarget("objectEmpty").attachDisplay(null, this._onDisplay, this);
			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);
			this.UserGroupIDTable = this.oView.byId("idUserGroupIDTable");
			this.setModel(oViewModel, "detailView");

			this._oODataModel = this.getOwnerComponent().getModel();
			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
			this._onMultipleUser = [];
			this._aTableSearchState = [];
			// this._oTPC = new TablePersoController({
			// 	table: this.byId("idUserGroupIDTable"),
			// 	componentName: "com.avangrid.ui.cpadmin",
			// 	//resetAllMode: ResetAllMode.ServiceReset,  //cmnt E834441
			// 	persoService: UserTableFunc
			// }).activate(); //Added by E834441
			// Peronalisation from ushell service to persist the settings
			if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {

				var oComponent = sap.ui.core.Component.getOwnerComponentFor(this.getView());
				this.oPersonalizationService = sap.ushell.Container.getService("Personalization");
				var oPersId = {
					container: "TablePersonalisation", //any
					item: "idUserGroupIDTable" //any- I have used the table name 
				};
				// define scope 
				var oScope = {
					keyCategory: this.oPersonalizationService.constants.keyCategory.FIXED_KEY,
					writeFrequency: this.oPersonalizationService.constants.writeFrequency.LOW,
					clientStorageAllowed: true
				};
				// Get a Personalizer
				var oPersonalizer = this.oPersonalizationService.getPersonalizer(oPersId, oScope, oComponent);
				this.oPersonalizationService.getContainer("TablePersonalisation", oScope, oComponent)
					.fail(function() {})
					.done(function(oContainer) {
						this.oContainer = oContainer;
						this.oVariantSetAdapter = new sap.ushell.services.Personalization.VariantSetAdapter(this.oContainer);
						// get variant set which is stored in backend
						this.oVariantSet = this.oVariantSetAdapter.getVariantSet("idUserGroupIDTable");
						if (!this.oVariantSet) { //if not in backend, then create one
							this.oVariantSet = this.oVariantSetAdapter.addVariantSet("idUserGroupIDTable");
						}
						// array to store the existing variants
						Variants = [];
						// now get the existing variants from the backend to show as list
						for (var key in this.oVariantSet.getVariantNamesAndKeys()) {
							if (this.oVariantSet.getVariantNamesAndKeys().hasOwnProperty(key)) {
								var oVariantItemObject = {};
								oVariantItemObject.Key = this.oVariantSet.getVariantNamesAndKeys()[key];
								oVariantItemObject.Name = key;
								Variants.push(oVariantItemObject);
							}
						}
						// create JSON model and attach to the variant management UI control
						this.oVariantModel = new sap.ui.model.json.JSONModel();
						this.oVariantModel.oData.Variants = Variants;
						this.getView().byId("Variants").setModel(this.oVariantModel, "VariantsModel");
					}.bind(this));
				// create table persco controller
				this.oTablepersoService = new TablePersoController({
					table: this.getView().byId("idUserGroupIDTable"),
					persoService: oPersonalizer
				});

			}
		},
		// onNavBack: function() {
		// 	var sPreviousHash = History.getInstance().getPreviousHash();

		// 	if (sPreviousHash !== undefined) {
		// 		history.go(-1);
		// 	} else {
		// 		this.getRouter().navTo("", {}, true);
		// 	}
		// },

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler when the share by E-Mail button has been clicked
		 * @public
		 */
		onSendEmailPress: function() {
			var oViewModel = this.getModel("detailView");

			URLHelper.triggerEmail(
				null,
				oViewModel.getProperty("/shareSendEmailSubject"),
				oViewModel.getProperty("/shareSendEmailMessage")
			);
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			var sObjectId = oEvent.getParameter("arguments").objectId;
			this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
			if (sObjectId != "X") {
				this.getModel().metadataLoaded().then(function() {
					var sObjectPath = this.getModel().createKey("USERGROUPHEADSet", {
						GroupId: sObjectId
					});
					this._bindView("/" + sObjectPath);
				}.bind(this));
				this.onDisplayUserGroup();
			} else {
				this.onCreateNewUserGroup();
			}

		},

		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		_bindView: function(sObjectPath) {
			// Set busy indicator during view binding
			var oViewModel = this.getModel("detailView");

			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearListListSelection();
				return;
			}

			var sPath = oElementBinding.getPath(),
				oResourceBundle = this.getResourceBundle(),
				oObject = oView.getModel().getObject(sPath),
				sObjectId = oObject.GroupName,
				sObjectName = oObject.GroupName,
				oViewModel = this.getModel("detailView");

			this.getOwnerComponent().oListSelector.selectAListItem(sPath);

			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},

		_onMetadataLoaded: function() {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView");

			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			oViewModel.setProperty("/delay", 0);

			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		},

		/**
		 * Set the full screen mode to false and navigate to list page
		 */
		onCloseDetailPress: function() {
			this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", false);
			// No item should be selected on list after detail page is closed
			this.getOwnerComponent().oListSelector.clearMasterListSelection();
			this.getRouter().navTo("list");
		},

		/**
		 * Toggle between full and non full screen mode.
		 */
		toggleFullScreen: function() {
			var bFullScreen = this.getModel("appView").getProperty("/actionButtonsInfo/midColumn/fullScreen");
			this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", !bFullScreen);
			if (!bFullScreen) {
				// store current layout and go full screen
				this.getModel("appView").setProperty("/previousLayout", this.getModel("appView").getProperty("/layout"));
				this.getModel("appView").setProperty("/layout", "MidColumnFullScreen");
			} else {
				// reset to previous layout
				this.getModel("appView").setProperty("/layout", this.getModel("appView").getProperty("/previousLayout"));
			}
		},
		onAddUser: function() {
			var oView = this.getView();
			if (!this.byId("AddUserDialog")) {
				Fragment.load({
					id: oView.getId(),
					name: "com.avangrid.ui.cpadmin.fragments.AddUserDialog",
					controller: this
				}).then(function(oDialog) {
					oView.addDependent(oDialog);
					oDialog.open();
				});
			} else {
				this.byId("AddUserDialog").open();
			}
		},
		handleSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oBinding = oEvent.getSource().getBinding("items");
			if (sValue != "") {
				var oFilter = new Filter("UseridPat", FilterOperator.EQ, sValue);

				oBinding.filter([oFilter]);

			} else {

				oBinding.filter([]);
			}
		},
		handleClose: function(oEvent) {
			// reset the filter
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([]);
			var aContexts = oEvent.getParameter("selectedContexts");
			if (aContexts && aContexts.length) {
				MessageToast.show("You have chosen " + aContexts.map(function(oContext) {
					return oContext.getObject().Name;
				}).join(", "));
			}

		},
		_onDisplay: function(oEvent) {
			var oViewModel = this.getModel("detailView");

			oViewModel.setProperty("/busy", true);

		},
		onListItemPress: function(oEvent) {

			var ConUname = oEvent.getSource().getBindingContext().getPath();
			this.getModel("appView").setProperty("/layout", "ThreeColumnsEndExpanded");
			this.getRouter().navTo("UserDetail");

		},

		onDelete: function() {

		},

		onDeleteGroup: function() {
			var that = this;
			var oViewModel = this.getModel("detailView"),
				sPath = this.getView().getElementBinding().getPath(),
				sObjectHeader = this._oODataModel.getProperty(sPath + "/GroupName"),
				//sQuestion = this.getResourceBundle.getText("deleteText", sObjectHeader),
				//sSuccessMessage = this.getResourceBundle.getText("deleteSuccess", sObjectHeader);

				sQuestion = "The Group " + sObjectHeader + " will be deleted",
				sSuccessMessage = sObjectHeader + " has been deleted";

			var fnMyAfterDeleted = function() {
				MessageBox.error(sSuccessMessage);
				oViewModel.setProperty("/busy", false);
				that.oRouter.navTo("list");
				//var oNextItemToSelect = that.getOwnerComponent().oListSelector.findNextItem(sPath);
				//that.getModel("appView").setProperty("/itemToSelect", oNextItemToSelect.getBindingContext().getPath()); //save last deleted
			};
			this._confirmDeletionByUser({
				question: sQuestion
			}, [sPath], fnMyAfterDeleted);
		},
		/* eslint-disable */ // using more then 4 parameters for a function is justified here
		_confirmDeletionByUser: function(oConfirmation, aPaths, fnAfterDeleted, fnDeleteCanceled, fnDeleteConfirmed) {
			/* eslint-enable */
			// Callback function for when the user decides to perform the deletion
			var fnDelete = function() {
				// Calls the oData Delete service
				this._callDelete(aPaths, fnAfterDeleted);
			}.bind(this);

			// Opens the confirmation dialog
			MessageBox.show(oConfirmation.question, {
				icon: oConfirmation.icon || MessageBox.Icon.WARNING,
				title: oConfirmation.title,
				actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
				onClose: function(oAction) {
					if (oAction === MessageBox.Action.OK) {
						fnDelete();
					} else if (fnDeleteCanceled) {
						fnDeleteCanceled();
					}
				}
			});
		},
		/**
		 * Performs the deletion of a list of entities.
		 * @param {array} aPaths -  Array of strings representing the context paths to the entities to be deleted. Currently only one is supported.
		 * @param {callback} fnAfterDeleted (optional) - called after deletion is done. 
		 * @return a Promise that will be resolved as soon as the deletion process ended successfully.
		 * @function
		 * @private
		 */
		_callDelete: function(aPaths, fnAfterDeleted) {
			var oViewModel = this.getModel("detailView");
			oViewModel.setProperty("/busy", true);
			var fnFailed = function() {
				this._oODataModel.setUseBatch(true);
			}.bind(this);
			var fnSuccess = function() {
				if (fnAfterDeleted) {
					fnAfterDeleted();
					this._oODataModel.setUseBatch(true);
				}
				oViewModel.setProperty("/busy", false);
			}.bind(this);
			return this._deleteOneEntity(aPaths[0], fnSuccess, fnFailed);
		},
		_deleteOneEntity: function(sPath, fnSuccess, fnFailed) {
			var oPromise = new Promise(function(fnResolve, fnReject) {
				this._oODataModel.setUseBatch(false);
				this._oODataModel.remove(sPath, {
					success: fnResolve,
					error: fnReject,
					async: true
				});
			}.bind(this));
			oPromise.then(fnSuccess, fnFailed);
			return oPromise;
		},
		onCreateNewUserGroup: function() {
			this.getView().byId("detailPage").setBusy(false);
			this.getView().byId("idCreateInputsDisplay").setVisible(false);
			this.getView().byId("idCreateInputs").setVisible(true);
			this.getView().byId("idGroupSave").setVisible(true);
			this.getView().byId("idEditAction").setVisible(false);
			this.getView().byId("idDeleteAction").setVisible(false);
			this.getView().byId("idUserGroupName").setEditable(true);
			this.getView().byId("idUserGroupName").setValue("");
			this.getView().byId("idUserGroupDesc").setValue("");
			this.getView().byId("idUserGroupIDTable").clearSelection();

			this.getView().byId("idUserGroupIDTableDisplay").setVisible(true);
			this.getView().byId("idUserGroupIDTable").setVisible(false);
			//this.emptyModel();

		},
		emptyModel: function() {
			// create an entry in the Products collection with the specified properties and values as initial data
			// var oContext =  this.getModel().createEntry("/USERGROUPHEADSet", {
			// 	properties: {
			// 		"GroupId": "",
			// 	"GroupName": "",
			// 	"GroupDescr": "",
			// 	"Inactive": ""
			// 	}
			// });
			// bind a form against the transient context for the newly created entity
			//oForm.setBindingContext(oContext);

			// submit the changes: creates entity in the back end
			// this.getModel().submitChanges({
			// 	success: function(){
			// 		alert("success");
			// 	},
			// 	error: function(){
			// 		alert("fail");
			// 	}
			// });
			// handle successful creation or reset
			// oContext.created().then(
			// 	function() { /* successful creation */ },
			// 	function() { /* deletion of the created entity before it is persisted */ }
			// );

			// delete the created entity by resetting the corresponding change
			var oContext = this.getView().byId("idUserGroupIDTable").getBindingContext();
			this.getModel().resetChanges([oContext.getPath()], undefined, /*bDeleteCreatedEntities*/ true);
		},
		onDisplayUserGroup: function() {
			this.getView().byId("detailPage").setBusy(false);
			this.getView().byId("idCreateInputsDisplay").setVisible(true);
			this.getView().byId("idCreateInputs").setVisible(false);
			this.getView().byId("idGroupSave").setVisible(false);
			this.getView().byId("idGroupUpdate").setVisible(false);
			this.getView().byId("idEditAction").setVisible(true);
			this.getView().byId("idUserGroupName").setEditable(true);
			this.getView().byId("idUserGroupIDTableDisplay").setVisible(false);
			this.getView().byId("idUserGroupIDTable").setVisible(true);
			//this.getView().byId("idInfoSave").setVisible(false);

			//this.getView().byId("idNewTitle").setVisible(false);
			//this.getView().byId("idDisplayTitle").setVisible(true);
		},

		AddUsersToGroup: function(oEvent) {
			this._onMultipleUser = [];
			var that = this;
			var aContexts = oEvent.getParameter("selectedContexts");
			if (aContexts && aContexts.length) {
				var data = aContexts.map(function(oContext) {
					that._onMultipleUser.push({
						"ConUname": oContext.getObject().ConUname
					});

				});
			}

			//this.onUserGroupSave();
			this.onUsersAddGroup();

		},

		onUsersAddGroup: function() {
			var idUserGroupName = this.getView().byId("idUserGroupName").getValue();
			var idUserGroupDesc = this.getView().byId("idUserGroupDesc").getValue();
			var idActiveGroup = this.getView().byId("idActiveGroup").getSelected();
			var idUserGroupID = this.getView().byId("titleGriupID").getText();
			//this._onMultipleUser = [];

			var Payload = {
				"GroupId": idUserGroupID,
				"GroupName": idUserGroupName,
				"GroupDescr": idUserGroupDesc,
				"Inactive": "",
				"UsergroupHeadToAssiNav": this._onMultipleUser
			};
			var that = this;
			if (this.onGroupValidationCheck()) {
				this.getModel().create('/USERGROUPHEADSet', Payload, {
						success: function(oData, response) {
							if (response.headers["sap-message"]) {
								var hdrMessage = response.headers["sap-message"];
								var hdrMessageObject = JSON.parse(hdrMessage);
								MessageBox.error(hdrMessageObject.message);
							} else {
								MessageBox.success("User group Created Successfully");
								that.getRouter().navTo("list");
							}

						},
						error: function() {
							// Error
							MessageBox.error("User group Creation failed");
						}
					}

				);
			}

			//this._oODataModel.refresh(true,false,"changes");

		},

		onUserGroupSave: function() {

			var idUserGroupName = this.getView().byId("idUserGroupName").getValue();
			var idUserGroupDesc = this.getView().byId("idUserGroupDesc").getValue();
			var idActiveGroup = this.getView().byId("idActiveGroup").getSelected();
			var Payload = {
				"GroupName": idUserGroupName,
				"GroupDescr": idUserGroupDesc,
				"Inactive": (idActiveGroup == true ? "" : "X"),
				"UsergroupHeadToAssiNav": this._onMultipleUser

			};
			var that = this;
			if (this.onGroupValidationCheck()) {
				this.getModel().create('/USERGROUPHEADSet', Payload, {
						success: function(oData, response) {
							if (response.headers["sap-message"]) {
								var hdrMessage = response.headers["sap-message"];
								var hdrMessageObject = JSON.parse(hdrMessage);
								MessageBox.error(hdrMessageObject.message);
							} else {
								MessageBox.success("User group Created Successfully");
								that.getRouter().navTo("list");
							}

						},
						error: function() {
							// Error
							MessageBox.error("User group Creation failed");
						}
					}

				);
			}
		},

		onUserGroupUpdate: function() {
			var idUserGroupName = this.getView().byId("idUserGroupName").getValue();
			var idUserGroupDesc = this.getView().byId("idUserGroupDesc").getValue();
			var idActiveGroup = this.getView().byId("idActiveGroup").getSelected();
			var idUserGroupID = this.getView().byId("titleGriupID").getText();
			//this._onMultipleUser = [];

			var Payload = {
				"GroupId": idUserGroupID,
				"GroupName": idUserGroupName,
				"GroupDescr": idUserGroupDesc,
				"Inactive": (idActiveGroup == true ? "" : "X"),
				"UsergroupHeadToAssiNav": this._onMultipleUser
			};

			if (this.onGroupValidationCheck()) {
				this.getModel().create('/USERGROUPHEADSet', Payload, {
						success: function(oData, response) {

							if (response.headers["sap-message"]) {
								var hdrMessage = response.headers["sap-message"];
								var hdrMessageObject = JSON.parse(hdrMessage);
								MessageBox.error(hdrMessageObject.message);
							} else {
								MessageBox.success("User group Updated Successfully");
							}

						},
						error: function() {
							// Error
							MessageBox.error("User group Updation failed");
						}
					}

				);
			}
			//this._oODataModel.refresh(true,false,"changes");

		},

		onDeleteUser: function(oEvent) {

			var oTable = this.getView().byId('idUserGroupIDTable');
			var selectedIndices = oTable.getSelectedIndices();

			this._onDeletedUsers = [];

			var idUserGroupName = this.getView().byId("idUserGroupName").getValue();
			var idUserGroupDesc = this.getView().byId("idUserGroupDesc").getValue();
			var idUserGroupID = this.getView().byId("titleGriupID").getText();
			if (selectedIndices) {
				//var idUserGroupID = this.getView().byId("titleGriupID").getText();
				var tableData = oTable.getBindingContext().getObject({
					expand: "UsergroupHeadToAssiNav"
				}).UsergroupHeadToAssiNav;
				for (var index = 0; index < selectedIndices.length; index++) {

					var tableIndex = selectedIndices[index];
					var tableRow = tableData[tableIndex];

					this._onDeletedUsers.push({
						"ConUname": tableRow.ConUname,
						"UserDel": "X"
					});

				}

				var Payload = {
					"GroupId": idUserGroupID,
					"GroupName": idUserGroupName,
					"GroupDescr": idUserGroupDesc,
					"Inactive": "",
					"UsergroupHeadToAssiNav": this._onDeletedUsers
				};
				this.getModel().create('/USERGROUPHEADSet', Payload, {
						success: function(oData, response) {
							if (response.headers["sap-message"]) {
								var hdrMessage = response.headers["sap-message"];
								var hdrMessageObject = JSON.parse(hdrMessage);
								MessageBox.error(hdrMessageObject.message);
							} else {
								MessageBox.error("User group Deleted Successfully");
								oTable.clearSelection();
							}

						},
						error: function() {
							// Error
							MessageBox.error("User group Deletion failed");
						}
					}

				);

			} else {
				MessageBox.error("Please select atleast one User to delete");
			}

			//oEvent.getSource().getParent().getParent().getSelectedContextPaths()[0].split("('")[1].split("')")[0]
		},

		onGroupValidationCheck: function() {
			var idUserGroupName = this.getView().byId("idUserGroupName").getValue();
			var idUserGroupDesc = this.getView().byId("idUserGroupDesc").getValue();

			if ((idUserGroupName == "") || (idUserGroupDesc == "")) {
				MessageBox.error("Please fill all mandatory fields...");
				return false;

			} else {
				return true;
			}

		},

		onEditGroup: function() {
			this.getView().byId("idCreateInputsDisplay").setVisible(false);
			this.getView().byId("idCreateInputs").setVisible(true);
			this.getView().byId("idEditAction").setVisible(false);
			this.getView().byId("idGroupUpdate").setVisible(true);
			this.getView().byId("idGroupSave").setVisible(false);
			this.getView().byId("idUserGroupName").setEditable(false);
			this.getView().byId("idDeleteAction").setVisible(true);

		},
		//Arrange/ Rearrange Table columns added by E834441
		onhide: function(oEvent) {
			this._oTPC.openDialog();
		},
		onSearch: function(oEvent) {
			var oTableSearchState = [],
				sQuery = oEvent.getParameter("query");

			if (sQuery && sQuery.length > 0) {
				oTableSearchState = [new Filter("ConUname", FilterOperator.Contains, sQuery)];
			}

			this.UserGroupIDTable.getBinding("rows").filter(oTableSearchState, "Application");
		},
		onSort: function() {
			var oView = this.getView();
			if (!this.byId("sortDialog")) {
				Fragment.load({
					id: oView.getId(),
					name: "com.avangrid.ui.cpadmin.fragments.UserSortDialog",
					controller: this
				}).then(function(oDialog) {
					oView.addDependent(oDialog);
					oDialog.open();
				});
			} else {
				this.byId("sortDialog").open();
			}
		},
		handleSortDialogConfirm: function(oEvent) {
			var oTable = this.byId("idUserGroupIDTable"),
				mParams = oEvent.getParameters(),
				oBinding = oTable.getBinding("rows"),
				sPath,
				bDescending,
				aSorters = [];

			sPath = mParams.sortItem.getKey();
			bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending));
			// apply the selected sort and group settings
			oBinding.sort(aSorters);
		},
		onFilter: function() {
			var oView = this.getView();
			if (!this.byId("userfilterDialog")) {
				Fragment.load({
					id: oView.getId(),
					name: "com.avangrid.ui.cpadmin.fragments.UserFilterDialog",
					controller: this
				}).then(function(oDialog) {
					oView.addDependent(oDialog);
					oDialog.open();
				});
			} else {
				this.byId("userfilterDialog").open();
			}
		},
		handleFilterDialogConfirm: function(oEvent) {
			var oTable = this.byId("idUserGroupIDTable"),
				mParams = oEvent.getParameters(),
				oBinding = oTable.getBinding("rows"),
				aFilters = [];

			mParams.filterItems.forEach(function(oItem) {

				aFilters.push(new Filter(oItem.getKey(), FilterOperator.EQ, oItem.getText()));

			});

			// apply filter settings
			oBinding.filter(aFilters);

		},
		// onExport: function() {
		// 	var sUrl = "/sap/opu/odata/sap/ZADMIN_PORTAL_SRV/USERGROUPHEADSet?$format=xlsx";
		// 	var encodeUrl = encodeURI(sUrl);
		// 	sap.m.URLHelper.redirect(encodeUrl, false);
		// },
		onPersoButtonPressed: function(oEvent) {
			this.oTablepersoService.openDialog({
				ok: "this.onPerscoDonePressed.bind(this)"
			});
			this._waitForDialog(this);
		},
		_waitForDialog: function(that) {
			if (typeof that.oTablepersoService._oDialog !== "undefined") {
				that.oTablepersoService._oDialog.attachConfirm(that, that.onPerscoDonePressed.bind(that));
			} else {
				setTimeout(this._waitForDialog, 250, that);
			}
		},
		onPerscoDonePressed: function(oEvent) {
			this.oTablepersoService.savePersonalizations();
		},
		onSaveAs: function(oEvent) {
			// get variant parameters:
			var VariantParam = oEvent.getParameters();
			// get columns data: 
			var aColumnsData = [];
			this.getView().byId("idUserGroupIDTable").getColumns().forEach(function(oColumn, index) {
				var aColumn = {};
				aColumn.fieldName = oColumn.getProperty("name");
				aColumn.Id = oColumn.getId();
				aColumn.index = index;
				aColumn.Visible = oColumn.getVisible();
				aColumnsData.push(aColumn);
			});

			this.oVariant = this.oVariantSet.addVariant(VariantParam.name);
			if (this.oVariant) {
				this.oVariant.setItemValue("ColumnsVal", JSON.stringify(aColumnsData));
				if (VariantParam.def === true) {
					this.oVariantSet.setCurrentVariantKey(this.oVariant.getVariantKey());
				}
				this.oContainer.save().done(function() {
					// Tell the user that the personalization data was saved
				});
			}
		},
		onSelect: function(oEvent) {
			var selectedKey = oEvent.getParameters().key;
			for (var i = 0; i < oEvent.getSource().getVariantItems().length; i++) {
				if (oEvent.getSource().getVariantItems()[i].getProperty("key") === selectedKey) {
					var selectedVariant = oEvent.getSource().getVariantItems()[i].getProperty("text");
					break;
				}
			}
			this._setSelectedVariantToTable(selectedVariant);
		},

		_setSelectedVariantToTable: function(oSelectedVariant) {
			if (oSelectedVariant) {
				var sVariant = this.oVariantSet.getVariant(this.oVariantSet.getVariantKeyByName(oSelectedVariant));
				var aColumns = JSON.parse(sVariant.getItemValue("ColumnsVal"));

				// Hide all columns first
				this.getView().byId("idUserGroupIDTable").getColumns().forEach(function(oColumn) {
					oColumn.setVisible(false);
				});
				// re-arrange columns according to the saved variant

				aColumns.forEach(function(aColumn) {
					var aTableColumn = $.grep(this.getView().byId("idUserGroupIDTable").getColumns(), function(el, id) {
						return el.getProperty("name") === aColumn.fieldName;
					});
					if (aTableColumn.length > 0) {
						aTableColumn[0].setVisible(aColumn.Visible);
						this.getView().byId("idUserGroupIDTable").removeColumn(aTableColumn[0]);
						this.getView().byId("idUserGroupIDTable").insertColumn(aTableColumn[0], aColumn.index);
					}
				}.bind(this));
			}
			// null means the standard variant is selected or the variant which is not available, then show all columns
			else {
				this.getView().byId("idUserGroupIDTable").getColumns().forEach(function(oColumn) {
					oColumn.setVisible(true);
				});
			}
		},
		onManage: function(oEvent) {
			var aParameters = oEvent.getParameters();
			// rename variants
			if (aParameters.renamed.length > 0) {
				aParameters.renamed.forEach(function(aRenamed) {
					var sVariant = this.oVariantSet.getVariant(aRenamed.key),
						sItemValue = sVariant.getItemValue("ColumnsVal");
					// delete the variant 
					this.oVariantSet.delVariant(aRenamed.key);
					// after delete, add a new variant
					var oNewVariant = this.oVariantSet.addVariant(aRenamed.name);
					oNewVariant.setItemValue("ColumnsVal", sItemValue);
				}.bind(this));
			}
			// default variant change
			if (aParameters.def !== "*standard*") {
				this.oVariantSet.setCurrentVariantKey(aParameters.def);
			} else {
				this.oVariantSet.setCurrentVariantKey(null);
			}
			// Delete variants
			if (aParameters.deleted.length > 0) {
				aParameters.deleted.forEach(function(aDelete) {
					this.oVariantSet.delVariant(aDelete);
				}.bind(this));
			}
			//  Save the Variant Container
			this.oContainer.save().done(function() {
				// Tell the user that the personalization data was saved
			});
		},
		onRefresh: function() {
			this.getView().getModel().read("/USERGROUPHEADSet", {
				urlParameters: {
					'$expand': "UsergroupHeadToAssiNav"
				},

				success: function(oData) {

				},
				error: function(snItemsError1) {
					MessageBox.error(JSON.parse(snItemsError1.responseText).error.message.value);
				}
			});
			//this.getView().byId("idUserTable").getBinding("items").refresh();
		},
		onNavBack: function() {

			this.getModel("appView").setProperty("/layout", "OneColumn");
			this.getRouter().navTo("list", {});
			//this.getOwnerComponent().getRouter().navTo("MessageList", {}, true);

		}

	});

});