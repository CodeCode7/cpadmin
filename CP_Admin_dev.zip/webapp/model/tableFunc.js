sap.ui.define(['sap/ui/thirdparty/jquery'],
	function(jQuery) {
	"use strict";

	// Very simple page-context personalization
	// persistence service, not for productive use!
	var tableFunc = {

		oData : {
			_persoSchemaVersion: "1.0",
			aColumns : [
				{
					id: "messageName",
					order: 0,
					text: "{i18n>MessageName}",
					visible: true
				},
				{
					id: "contractorUserName",
					order: 1,
					text: "{i18n>ContractorUserName}",
					visible: true
				},
				{
					id: "contractorUserGroup",
					order: 2,
					text: "{i18n>ContractorUserGroup}",
					visible: true
				},
				{
					id: "scheduledStart",
					order: 3,
					text: "{i18n>ScheduledStart}",
					visible: false
				},
				{
					id: "scheduledEnd",
					order: 4,
					text: "{i18n>ScheduledEnd}",
					visible: false
				},
				{
					id: "messageDescription",
					order: 5,
					text: "{i18n>MessageDescription}",
					visible: false
				},
				{
					id: "allContractors",
					order: 6,
					text: "{i18n>AllContractors}",
					visible: false
				},
				{
					id: "active",
					order: 7,
					text: "{i18n>Active}",
					visible: false
				},
				{
					id: "reminder",
					order: 8,
					text: "{i18n>Reminder}",
					visible: false
				},
				{
					id: "createdBy",
					order: 9,
					text: "{i18n>CreatedBy}",
					visible: false
				},
				{
					id: "createdOn",
					order: 10,
					text: "{i18n>CreatedOn}",
					visible: false
				}
			]
		},

		oResetData : {
			_persoSchemaVersion: "1.0",
			aColumns : [
				{
					id: "messageName",
					order: 0,
					text: "{i18n>MessageName}",
					visible: true
				},
				{
					id: "contractorUserName",
					order: 1,
					text: "{i18n>ContractorUserName}",
					visible: true
				},
				{
					id: "contractorUserGroup",
					order: 2,
					text: "{i18n>ContractorUserGroup}",
					visible: true
				},
				{
					id: "scheduledStart",
					order: 3,
					text: "{i18n>ScheduledStart}",
					visible: false
				},
				{
					id: "scheduledEnd",
					order: 4,
					text: "{i18n>ScheduledEnd}",
					visible: false
				},
				{
					id: "messageDescription",
					order: 5,
					text: "{i18n>MessageDescription}",
					visible: false
				},
				{
					id: "allContractors",
					order: 6,
					text: "{i18n>AllContractors}",
					visible: false
				},
				{
					id: "active",
					order: 7,
					text: "{i18n>Active}",
					visible: false
				},
				{
					id: "reminder",
					order: 8,
					text: "{i18n>Reminder}",
					visible: false
				},
				{
					id: "createdBy",
					order: 9,
					text: "{i18n>CreatedBy}",
					visible: false
				},
				{
					id: "createdOn",
					order: 10,
					text: "{i18n>CreatedOn}",
					visible: false
				}
			]
		}, // //cmnt E834441


		getPersData : function () {
			var oDeferred = new jQuery.Deferred();
			if (!this._oBundle) {
				this._oBundle = this.oData;
			}
			oDeferred.resolve(this._oBundle);
			// setTimeout(function() {
			// 	oDeferred.resolve(this._oBundle);
			// }.bind(this), 2000);
			return oDeferred.promise();
		},

		setPersData : function (oBundle) {
			var oDeferred = new jQuery.Deferred();
			this._oBundle = oBundle;
			oDeferred.resolve();
			return oDeferred.promise();
		},

		getResetPersData : function () {
			var oDeferred = new jQuery.Deferred();

			// oDeferred.resolve(this.oResetData);

			setTimeout(function() {
				oDeferred.resolve(this.oResetData);
			}.bind(this), 2000);

			return oDeferred.promise();
		},  //cmnt E834441

		resetPersData : function () {
			var oDeferred = new jQuery.Deferred();

			//set personalization
			this._oBundle = this.oResetData;

			//reset personalization, i.e. display table as defined
			//this._oBundle = null;

			oDeferred.resolve();

			// setTimeout(function() {
			// 	this._oBundle = this.oResetData;
			// 	oDeferred.resolve();
			// }.bind(this), 2000);

			return oDeferred.promise();
		} //cmnt E834441
	};

	return tableFunc;
});