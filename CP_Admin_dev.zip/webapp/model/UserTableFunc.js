sap.ui.define(['sap/ui/thirdparty/jquery'],
	function(jQuery) {
	"use strict";

	// Very simple page-context personalization
	// persistence service, not for productive use!
	var tableFunc = {

		oData : {
			_persoSchemaVersion: "1.0",
			aColumns : [
				{
					id: "txtUserID",
					order: 0,
					text: "{i18n>txtUserID}",
					visible: true
				},
				{
					id: "txtUserName",
					order: 1,
					text: "{i18n>txtUserName}",
					visible: true
				},
				{
					id: "txtLastName",
					order: 2,
					text: "{i18n>txtLastName}",
					visible: true
				},
				{
					id: "txtEmail",
					order: 3,
					text: "{i18n>txtEmail}",
					visible: false
				},
				{
					id: "txtVendor",
					order: 4,
					text: "{i18n>txtVendor}",
					visible: false
				},
				{
					id: "txtUserGroups",
					order: 5,
					text: "{i18n>txtUserGroups}",
					visible: false
				},
				{
					id: "txtCreationDate",
					order: 6,
					text: "{i18n>txtCreationDate}",
					visible: false
				},
				{
					id: "txtStartDate",
					order: 7,
					text: "{i18n>txtStartDate}",
					visible: false
				},
				{
					id: "txtEndDate",
					order: 8,
					text: "{i18n>txtEndDate}",
					visible: false
				},
				{
					id: "txtSuperUser",
					order: 9,
					text: "{i18n>txtSuperUser}",
					visible: false
				}
			]
		},

		oResetData : {
			_persoSchemaVersion: "1.0",
			aColumns : [
				{
					id: "txtUserID",
					order: 0,
					text: "{i18n>txtUserID}",
					visible: true
				},
				{
					id: "txtUserName",
					order: 1,
					text: "{i18n>txtUserName}",
					visible: true
				},
				{
					id: "txtLastName",
					order: 2,
					text: "{i18n>txtLastName}",
					visible: true
				},
				{
					id: "txtEmail",
					order: 3,
					text: "{i18n>txtEmail}",
					visible: false
				},
				{
					id: "txtVendor",
					order: 4,
					text: "{i18n>txtVendor}",
					visible: false
				},
				{
					id: "txtUserGroups",
					order: 5,
					text: "{i18n>txtUserGroups}",
					visible: false
				},
				{
					id: "txtCreationDate",
					order: 6,
					text: "{i18n>txtCreationDate}",
					visible: false
				},
				{
					id: "txtStartDate",
					order: 7,
					text: "{i18n>txtStartDate}",
					visible: false
				},
				{
					id: "txtEndDate",
					order: 8,
					text: "{i18n>txtEndDate}",
					visible: false
				},
				{
					id: "txtSuperUser",
					order: 9,
					text: "{i18n>txtSuperUser}",
					visible: false
				}
			]
		}, // //cmnt E834441


		getPersData : function () {
			var oDeferred = new jQuery.Deferred();
			if (!this._oBundle) {
				this._oBundle = this.oData;
			}
			oDeferred.resolve(this._oBundle);
			// setTimeout(function() {
			// 	oDeferred.resolve(this._oBundle);
			// }.bind(this), 2000);
			return oDeferred.promise();
		},

		setPersData : function (oBundle) {
			var oDeferred = new jQuery.Deferred();
			this._oBundle = oBundle;
			oDeferred.resolve();
			return oDeferred.promise();
		},

		getResetPersData : function () {
			var oDeferred = new jQuery.Deferred();

			// oDeferred.resolve(this.oResetData);

			setTimeout(function() {
				oDeferred.resolve(this.oResetData);
			}.bind(this), 2000);

			return oDeferred.promise();
		},  //cmnt E834441

		resetPersData : function () {
			var oDeferred = new jQuery.Deferred();

			//set personalization
			this._oBundle = this.oResetData;

			//reset personalization, i.e. display table as defined
			//this._oBundle = null;

			oDeferred.resolve();

			// setTimeout(function() {
			// 	this._oBundle = this.oResetData;
			// 	oDeferred.resolve();
			// }.bind(this), 2000);

			return oDeferred.promise();
		} //cmnt E834441
	};

	return tableFunc;
});